/* 前后端共享的类型写在这里 */

export const USER_ROLES = ['admin', 'user'] as const;
export type UserRole = (typeof USER_ROLES)[number];
export const USER_ROLE_LABELS: Record<UserRole, string> = {
  admin: '管理员',
  user: '普通用户',
};

export const FILE_TYPES = ['file', 'folder'] as const;
export type FileType = (typeof FILE_TYPES)[number];

export const API_PERMISSIONS = ['read', 'readwrite'] as const;
export type ApiPermission = (typeof API_PERMISSIONS)[number];
export const API_PERMISSION_LABELS: Record<ApiPermission, string> = {
  read: '只读',
  readwrite: '读写',
};

export const SHARE_TYPES = ['file', 'folder'] as const;
export type ShareType = (typeof SHARE_TYPES)[number];

export interface UserInfo {
  id: string;
  username: string;
  role: UserRole;
  quotaBytes: number;
  usedBytes: number;
  isActive: boolean;
  canUpload: boolean;
  canShare: boolean;
  canUseApi: boolean;
  allowedFileTypes: string[] | null;
  createdAt: string;
}

export interface FileItem {
  id: string;
  name: string;
  type: FileType;
  parentId: string | null;
  sizeBytes: number;
  mimeType: string | null;
  userId: string;
  createdAt: string;
  updatedAt: string;
}

export interface ShareInfo {
  id: string;
  token: string;
  fileId: string;
  fileName: string;
  shareType: ShareType;
  hasPassword: boolean;
  expiresAt: string | null;
  allowDownload: boolean;
  createdBy: string;
  viewCount: number;
  createdAt: string;
}

export interface ApiKeyInfo {
  id: string;
  name: string;
  keyPrefix: string;
  permission: ApiPermission;
  quotaBytes: number | null;
  usedBytes: number;
  expiresAt: string | null;
  callCount: number;
  isActive: boolean;
  createdAt: string;
}

export interface InitRequest {
  username: string;
  password: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  user: UserInfo;
}

export interface InitResponse {
  token: string;
  user: UserInfo;
}

export interface FileListRequest {
  parentId?: string | null;
  sortBy?: 'name' | 'sizeBytes' | 'createdAt' | 'updatedAt' | 'type';
  sortOrder?: 'asc' | 'desc';
  search?: string;
  type?: FileType;
}

export interface FileListResponse {
  items: FileItem[];
  currentPath: { id: string | null; name: string }[];
}

export interface CreateFolderRequest {
  name: string;
  parentId?: string | null;
}

export interface RenameFileRequest {
  name: string;
}

export interface MoveFileRequest {
  targetParentId: string | null;
}

export interface CreateShareRequest {
  fileId: string;
  password?: string;
  expiresAt?: string | null;
  allowDownload?: boolean;
}

export interface CreateShareResponse {
  share: ShareInfo;
  shareUrl: string;
}

export interface ShareListResponse {
  items: ShareInfo[];
  total: number;
}

export interface SharePublicInfoResponse {
  file: FileItem;
  share: Omit<ShareInfo, 'token'>;
  needPassword: boolean;
  shareType: ShareType;
}

export interface ShareAccessResponse {
  file: FileItem;
  share: Omit<ShareInfo, 'token'>;
  children?: FileItem[];
  downloadUrl?: string;
}

export interface CreateUserRequest {
  username: string;
  password: string;
  role?: UserRole;
  quotaBytes?: number;
  canUpload?: boolean;
  canShare?: boolean;
  canUseApi?: boolean;
  allowedFileTypes?: string[];
}

export interface UpdateUserRequest {
  password?: string;
  role?: UserRole;
  quotaBytes?: number;
  isActive?: boolean;
  canUpload?: boolean;
  canShare?: boolean;
  canUseApi?: boolean;
  allowedFileTypes?: string[];
}

export interface UserListResponse {
  items: UserInfo[];
  total: number;
}

export interface CreateApiKeyRequest {
  name: string;
  permission: ApiPermission;
  quotaBytes?: number | null;
  expiresAt?: string | null;
}

export interface CreateApiKeyResponse {
  apiKey: ApiKeyInfo;
  key: string;
}

export interface DashboardStats {
  totalStorageBytes: number;
  totalQuotaBytes: number;
  totalUsers: number;
  totalFiles: number;
  totalApiCalls: number;
  recentUploads: FileItem[];
  recentShares: ShareInfo[];
  storageByUser: { username: string; usedBytes: number; quotaBytes: number; role: string }[];
}

export interface UploadResponse {
  file: FileItem;
}
