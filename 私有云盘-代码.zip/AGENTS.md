# 云端硬盘 (Cloud Drive) 应用

一个功能完整的云端网盘应用，支持文件上传下载、分享、用户管理、API 管理等功能。

## 技术架构

- **用户体系**: 自建用户名/密码认证（非平台用户体系），支持管理员与普通用户角色
- **文件存储**: 使用平台 dataloom 存储服务，元数据存数据库
- **鉴权方式**: JWT Token（前端 localStorage 存储）+ API Key（Header 鉴权）
- **分享机制**: 随机 token 生成公开链接，支持密码、过期时间、下载权限

## 数据库设计

### users 表
- id (uuid, PK)
- username (varchar, unique)
- passwordHash (varchar)
- role (admin/user)
- quotaBytes (bigint) - 存储配额
- usedBytes (bigint) - 已用存储
- isActive (boolean)
- canUpload (boolean)
- canShare (boolean)
- canUseApi (boolean)
- allowedFileTypes (text[] | null) - null 表示不限制
- createdAt / updatedAt (timestamptz)

### files 表
- id (uuid, PK)
- userId (uuid, FK → users)
- name (varchar)
- type (file/folder)
- parentId (uuid, nullable, 自引用)
- filePath (varchar) - dataloom file_path
- bucketId (varchar) - dataloom bucket_id
- sizeBytes (bigint)
- mimeType (varchar, nullable)
- createdAt / updatedAt (timestamptz)

### shares 表
- id (uuid, PK)
- token (varchar, unique)
- fileId (uuid, FK → files)
- shareType (file/folder)
- password (varchar, nullable) - bcrypt hash
- expiresAt (timestamptz, nullable)
- allowDownload (boolean)
- createdBy (uuid, FK → users)
- viewCount (int)
- createdAt (timestamptz)

### api_keys 表
- id (uuid, PK)
- keyHash (varchar, unique) - SHA256 of API key
- name (varchar)
- userId (uuid, FK → users)
- permission (read/readwrite)
- quotaBytes (bigint, nullable)
- usedBytes (bigint)
- expiresAt (timestamptz, nullable)
- callCount (int)
- isActive (boolean)
- createdAt (timestamptz)

## 前端页面

1. `/init` - 初始化页面（首次设置管理员）
2. `/login` - 登录页
3. `/files` - 文件管理（主页面）
4. `/share/:token` - 公开分享访问页
5. `/admin/users` - 用户管理（管理员）
6. `/admin/api` - API 管理（管理员）
7. `/admin/dashboard` - 仪表盘（管理员）

## 设计规范

### 色彩系统
- 主色：蓝色系（`#2563eb`），代表可靠、专业
- 背景：浅灰 `#f8fafc`
- 卡片：纯白 `#ffffff`
- 边框：`#e2e8f0`
- 文字：主文 `#0f172a`，次文 `#64748b`

### 布局
- 侧边栏导航 + 主内容区
- 侧边栏宽 240px，桌面端固定，移动端可折叠
- 内容区最大宽度不限，使用 padding 保持呼吸感

### 排版
- 标题：text-xl font-semibold
- 正文：text-sm text-slate-700
- 辅助文字：text-xs text-slate-500

### 间距
- 内容区 padding: p-6
- 卡片间距: gap-4
- 列表项间距: py-3
