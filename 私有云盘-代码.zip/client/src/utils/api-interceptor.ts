import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type { InternalAxiosRequestConfig } from 'axios';

const TOKEN_KEY = 'cloud_drive_token';

axiosForBackend.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) {
    config.headers.set('Authorization', `Bearer ${token}`);
  }
  return config;
});

axiosForBackend.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      const currentPath = window.location.pathname;
      if (!currentPath.includes('/login') && !currentPath.includes('/init') && !currentPath.includes('/share/')) {
        localStorage.removeItem(TOKEN_KEY);
        window.location.href = '/login';
      }
    }
    logger.error('API 请求失败', error);
    return Promise.reject(error);
  },
);

export function getApiErrorMessage(error: unknown): string {
  const err = error as { response?: { data?: { error?: { message?: string; fieldErrors?: Record<string, string[]> } } } };
  return err.response?.data?.error?.message || '操作失败，请重试';
}
