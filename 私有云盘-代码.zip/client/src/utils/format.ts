import dayjs from 'dayjs';

/**
 * 格式化文件大小（字节 → 人类可读）
 */
export function formatFileSize(bytes: number): string {
  if (bytes == null || Number.isNaN(bytes)) return '0 B';
  const numBytes = Number(bytes);
  if (numBytes <= 0) return '0 B';
  if (!Number.isFinite(numBytes)) return '∞ B';

  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const k = 1024;
  let i = Math.floor(Math.log(numBytes) / Math.log(k));
  if (i < 0) i = 0;
  if (i >= units.length) i = units.length - 1;
  const value = numBytes / Math.pow(k, i);
  return `${value.toFixed(value >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}

/**
 * 格式化日期时间
 */
export function formatDateTime(date: string | Date | null | undefined): string {
  if (!date) return '-';
  return dayjs(date).format('YYYY-MM-DD HH:mm:ss');
}

/**
 * 格式化日期
 */
export function formatDate(date: string | Date | null | undefined): string {
  if (!date) return '-';
  return dayjs(date).format('YYYY-MM-DD');
}

/**
 * 存储单位转换：数值 + 单位 → 字节数
 */
export function toBytes(value: number, unit: 'MB' | 'GB' | 'TB'): number {
  if (unit === 'MB') return value * 1024 * 1024;
  if (unit === 'GB') return value * 1024 * 1024 * 1024;
  return value * 1024 * 1024 * 1024 * 1024;
}

/**
 * 字节数 → 显示用的数值 + 单位（自动选最合适的单位）
 */
export function fromBytes(bytes: number): { value: number; unit: 'MB' | 'GB' | 'TB' } {
  const num = Number(bytes);
  if (!Number.isFinite(num) || num <= 0) {
    return { value: 0, unit: 'MB' };
  }
  const tb = num / (1024 * 1024 * 1024 * 1024);
  if (tb >= 1) {
    return { value: Number(tb.toFixed(2)), unit: 'TB' };
  }
  const gb = num / (1024 * 1024 * 1024);
  if (gb >= 1) {
    return { value: Number(gb.toFixed(2)), unit: 'GB' };
  }
  const mb = num / (1024 * 1024);
  return { value: Math.max(0, Number(mb.toFixed(0))), unit: 'MB' };
}

/**
 * 判断是否为图片文件
 */
export function isImageFile(mimeType: string | null | undefined): boolean {
  if (!mimeType) return false;
  return mimeType.startsWith('image/');
}
