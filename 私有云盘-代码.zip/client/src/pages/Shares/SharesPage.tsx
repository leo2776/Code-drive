import { useState } from 'react';
import {
  Share2,
  Copy,
  Trash2,
  File,
  Folder,
  Lock,
  Eye,
  Clock,
  ChevronLeft,
  ChevronRight,
  Inbox,
} from 'lucide-react';
import { toast } from 'sonner';
import { resolveAppUrl } from '@lark-apaas/client-toolkit/utils/resolveAppUrl';
import { Button } from '@client/src/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import { useShareList, useRemoveShare, getShareTypeLabel } from '@client/src/hooks/useShares';
import { formatDateTime } from '@client/src/utils/format';
import type { ShareInfo } from '@shared/api.interface';

export default function SharesPage() {
  const [page, setPage] = useState(1);
  const pageSize = 10;
  const { data, isLoading } = useShareList(page, pageSize);
  const removeMutation = useRemoveShare();
  const [deleteTarget, setDeleteTarget] = useState<ShareInfo | null>(null);

  const handleCopyLink = async (token: string) => {
    try {
      const shareUrl = resolveAppUrl(`/share/${token}`);
      await navigator.clipboard.writeText(shareUrl);
      toast.success('链接已复制到剪贴板');
    } catch {
      toast.error('复制失败');
    }
  };

  const handleConfirmDelete = () => {
    if (!deleteTarget) return;
    removeMutation.mutate(deleteTarget.id, {
      onSuccess: () => {
        setDeleteTarget(null);
      },
    });
  };

  const totalPages = data ? Math.max(1, Math.ceil(data.total / pageSize)) : 1;

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-slate-800 flex items-center gap-2">
            <Share2 className="w-5 h-5 text-blue-600" />
            我的分享
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            管理您创建的所有分享链接
          </p>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center py-20 text-slate-500">
            加载中...
          </div>
        ) : data?.items && data.items.length > 0 ? (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>文件名</TableHead>
                  <TableHead>类型</TableHead>
                  <TableHead>密码</TableHead>
                  <TableHead>过期时间</TableHead>
                  <TableHead className="text-center">浏览次数</TableHead>
                  <TableHead>创建时间</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.items.map((share: ShareInfo) => (
                  <TableRow key={share.id}>
                    <TableCell>
                      <div className="flex items-center gap-2 min-w-0">
                        {share.shareType === 'folder' ? (
                          <Folder className="w-4 h-4 text-amber-500 flex-shrink-0" />
                        ) : (
                          <File className="w-4 h-4 text-blue-500 flex-shrink-0" />
                        )}
                        <span className="truncate max-w-xs" title={share.fileName}>
                          {share.fileName}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-slate-600">
                      {getShareTypeLabel(share.shareType)}
                    </TableCell>
                    <TableCell>
                      {share.hasPassword ? (
                        <span className="inline-flex items-center gap-1 text-xs text-amber-600">
                          <Lock className="w-3 h-3" />
                          已加密
                        </span>
                      ) : (
                        <span className="text-xs text-slate-400">无</span>
                      )}
                    </TableCell>
                    <TableCell className="text-slate-600 text-xs">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        {share.expiresAt ? formatDateTime(share.expiresAt) : '永久有效'}
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-1 text-slate-600">
                        <Eye className="w-3 h-3 text-slate-400" />
                        {share.viewCount}
                      </div>
                    </TableCell>
                    <TableCell className="text-slate-500 text-xs">
                      {formatDateTime(share.createdAt)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleCopyLink(share.token)}
                          aria-label="复制链接"
                          title="复制链接"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setDeleteTarget(share)}
                          aria-label="撤销分享"
                          title="撤销分享"
                          className="text-red-500 hover:text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {/* 分页 */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t border-slate-200">
                <div className="text-sm text-slate-500">
                  共 {data.total} 条记录，第 {page} / {totalPages} 页
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page === 1}
                    aria-label="上一页"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    disabled={page === totalPages}
                    aria-label="下一页"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-slate-500">
            <Inbox className="w-12 h-12 text-slate-300 mb-3" />
            <p className="text-sm">暂无分享记录</p>
          </div>
        )}
      </div>

      {/* 删除确认弹窗 */}
      <Dialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>撤销分享</DialogTitle>
            <DialogDescription>
              确定要撤销「{deleteTarget?.fileName}」的分享吗？撤销后分享链接将立即失效。
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteTarget(null)}
              disabled={removeMutation.isPending}
            >
              取消
            </Button>
            <Button
              variant="destructive"
              onClick={handleConfirmDelete}
              disabled={removeMutation.isPending}
            >
              {removeMutation.isPending ? '撤销中...' : '确认撤销'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
