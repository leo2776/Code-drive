import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useNavigate, Link } from 'react-router-dom';
import { Cloud, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

import { useAuth } from '@client/src/contexts/auth-context';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@client/src/components/ui/card';
import { Input } from '@client/src/components/ui/input';
import { Button } from '@client/src/components/ui/button';
import {
  Field,
  FieldLabel,
  FieldContent,
  FieldError,
} from '@client/src/components/ui/field';

const initSchema = z
  .object({
    username: z
      .string()
      .min(1, { message: '请输入用户名' })
      .min(3, { message: '用户名至少 3 个字符' }),
    password: z
      .string()
      .min(1, { message: '请输入密码' })
      .min(6, { message: '密码至少 6 个字符' }),
    confirmPassword: z.string().min(1, { message: '请再次输入密码' }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: '两次输入的密码不一致',
    path: ['confirmPassword'],
  });

type InitFormData = z.infer<typeof initSchema>;

export default function InitPage() {
  const navigate = useNavigate();
  const { init, user, loading: authLoading, initialized } = useAuth();
  const [alreadyInitialized, setAlreadyInitialized] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<InitFormData>({
    resolver: zodResolver(initSchema),
    defaultValues: {
      username: '',
      password: '',
      confirmPassword: '',
    },
  });

  useEffect(() => {
    if (!authLoading && initialized && user) {
      navigate('/files', { replace: true });
    }
  }, [authLoading, initialized, user, navigate]);

  const onSubmit = async (data: InitFormData) => {
    try {
      await init(data.username, data.password);
      toast.success('管理员账号创建成功');
      navigate('/files', { replace: true });
    } catch (error: unknown) {
      const err = error as { response?: { data?: { error?: { message?: string } } } };
      const message = err.response?.data?.error?.message ?? '创建失败，请重试';
      if (message.includes('已初始化') || message.includes('initialized')) {
        setAlreadyInitialized(true);
      }
      toast.error(message);
    }
  };

  if (authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (alreadyInitialized) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
              <Cloud className="h-6 w-6 text-blue-600" />
            </div>
            <CardTitle className="text-2xl font-bold text-slate-900">
              系统已初始化
            </CardTitle>
            <CardDescription>
              管理员账号已创建，请使用登录账号进入系统
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link to="/login">前往登录</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
            <Cloud className="h-6 w-6 text-blue-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-slate-900">
            设置管理员账号
          </CardTitle>
          <CardDescription>
            欢迎使用云盘，请先创建管理员账号
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <Field>
              <FieldLabel>用户名</FieldLabel>
              <FieldContent>
                <Input
                  type="text"
                  placeholder="请输入用户名"
                  autoComplete="username"
                  {...register('username')}
                  aria-invalid={!!errors.username}
                />
                <FieldError errors={[errors.username]} />
              </FieldContent>
            </Field>

            <Field>
              <FieldLabel>密码</FieldLabel>
              <FieldContent>
                <Input
                  type="password"
                  placeholder="请输入密码"
                  autoComplete="new-password"
                  {...register('password')}
                  aria-invalid={!!errors.password}
                />
                <FieldError errors={[errors.password]} />
              </FieldContent>
            </Field>

            <Field>
              <FieldLabel>确认密码</FieldLabel>
              <FieldContent>
                <Input
                  type="password"
                  placeholder="请再次输入密码"
                  autoComplete="new-password"
                  {...register('confirmPassword')}
                  aria-invalid={!!errors.confirmPassword}
                />
                <FieldError errors={[errors.confirmPassword]} />
              </FieldContent>
            </Field>

            <Button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              disabled={isSubmitting}
            >
              {isSubmitting && (
                <Loader2 className="h-4 w-4 animate-spin" />
              )}
              开始使用
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
