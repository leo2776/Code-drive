import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { getDefaultBucketId } from '@lark-apaas/client-toolkit/tools/storage';
import { toast } from 'sonner';
import {
  Search,
  Plus,
  Upload,
  Grid3x3,
  List,
  ChevronRight,
  MoreVertical,
  Download,
  Pencil,
  ArrowRightLeft,
  Trash2,
  Share2,
  FolderOpen,
  FolderPlus,
  ArrowUpDown,
} from 'lucide-react';

import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@client/src/components/ui/breadcrumb';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@client/src/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@client/src/components/ui/alert-dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import { Empty, EmptyHeader, EmptyTitle, EmptyDescription, EmptyMedia } from '@client/src/components/ui/empty';
import { Label } from '@client/src/components/ui/label';

import {
  useFileList,
  useCreateFolder,
  useRenameFile,
  useDeleteFile,
  useGetDownloadUrl,
  useUploadComplete,
  FILES_QUERY_KEY,
} from './useFiles';
import { getFileCategory, FILE_ICON_MAP, formatFileSize, formatDateTime } from './fileUtils';
import { ShareDialog } from './ShareDialog';
import { MoveDialog } from './MoveDialog';
import { UploadProgressPanel, type UploadItem } from './UploadProgressPanel';
import { getApiErrorMessage } from '@client/src/lib/api-error';
import { StorageBar } from '@client/src/components/ui/storage-bar';
import { useAuth } from '@client/src/contexts/auth-context';

import type { FileItem } from '@shared/api.interface';

type SortBy = 'name' | 'sizeBytes' | 'updatedAt' | 'type';
type SortOrder = 'asc' | 'desc';
type ViewMode = 'list' | 'grid';

interface DataloomStorageBucket {
  uploadFile: (file: File) => Promise<{
    data: { file_path: string; bucket_id: string; download_url: string } | null;
    error: { message?: string; error_msg?: string } | null;
  }>;
}

interface DataloomStorage {
  from: (bucketId: string) => DataloomStorageBucket;
}

interface DataloomClient {
  storage: DataloomStorage;
}

/** 防抖 hook */
function useDebouncedValue<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState<T>(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

export default function FilesPage() {
  const queryClient = useQueryClient();
  const { user, refreshUser } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 导航状态
  const [parentId, setParentId] = useState<string | null>(null);
  const [currentPath, setCurrentPath] = useState<{ id: string | null; name: string }[]>([
    { id: null, name: '根目录' },
  ]);

  // 视图状态
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [sortBy, setSortBy] = useState<SortBy>('name');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebouncedValue(search, 300);

  // 拖拽状态
  const [isDragOver, setIsDragOver] = useState(false);
  const dragCounter = useRef(0);

  // 上传进度
  const [uploadItems, setUploadItems] = useState<UploadItem[]>([]);

  // 对话框状态
  const [newFolderOpen, setNewFolderOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [renameOpen, setRenameOpen] = useState(false);
  const [renameName, setRenameName] = useState('');
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [moveOpen, setMoveOpen] = useState(false);
  const [activeFile, setActiveFile] = useState<FileItem | null>(null);

  // 数据查询
  const { data, isLoading, isError } = useFileList({
    parentId,
    sortBy,
    sortOrder,
    search: debouncedSearch,
  });

  const createFolder = useCreateFolder(parentId);
  const renameFile = useRenameFile(parentId);
  const deleteFile = useDeleteFile(parentId);
  const getDownloadUrl = useGetDownloadUrl();
  const uploadComplete = useUploadComplete(parentId);

  // 当数据返回时更新面包屑
  useEffect(() => {
    if (data && data.currentPath) {
      setCurrentPath(data.currentPath);
    }
  }, [data]);

  const fileList = data?.items ?? [];

  const isAdmin = user?.role === 'admin';
  const remainingBytes = useMemo(() => {
    if (!user) return 0;
    if (isAdmin) return Number.MAX_SAFE_INTEGER;
    return Math.max(0, user.quotaBytes - user.usedBytes);
  }, [user, isAdmin]);

  /** 点击面包屑跳转 */
  const handleBreadcrumbClick = useCallback((index: number) => {
    const target = currentPath[index];
    if (!target) return;
    setParentId(target.id);
    setCurrentPath(currentPath.slice(0, index + 1));
  }, [currentPath]);

  /** 点击文件夹进入 */
  const handleEnterFolder = useCallback((folder: FileItem) => {
    setParentId(folder.id);
    // 先乐观更新面包屑，数据返回后会被覆盖
    setCurrentPath((prev) => [...prev, { id: folder.id, name: folder.name }]);
  }, []);

  /** 新建文件夹 */
  const handleCreateFolder = useCallback(() => {
    const name = newFolderName.trim();
    if (!name) {
      toast.error('请输入文件夹名称');
      return;
    }
    createFolder.mutate(name, {
      onSuccess: () => {
        toast.success('文件夹创建成功');
        setNewFolderOpen(false);
        setNewFolderName('');
      },
      onError: (error) => {
        toast.error(getApiErrorMessage(error, '创建文件夹失败'));
      },
    });
  }, [createFolder, newFolderName]);

  /** 重命名 */
  const openRename = useCallback((file: FileItem) => {
    setActiveFile(file);
    setRenameName(file.name);
    setRenameOpen(true);
  }, []);

  const handleRename = useCallback(() => {
    if (!activeFile) return;
    const name = renameName.trim();
    if (!name) {
      toast.error('请输入名称');
      return;
    }
    renameFile.mutate(
      { id: activeFile.id, name },
      {
        onSuccess: () => {
          toast.success('重命名成功');
          setRenameOpen(false);
          setActiveFile(null);
        },
        onError: (error) => {
          toast.error(getApiErrorMessage(error, '重命名失败'));
        },
      },
    );
  }, [activeFile, renameFile, renameName]);

  /** 删除 */
  const openDelete = useCallback((file: FileItem) => {
    setActiveFile(file);
    setDeleteOpen(true);
  }, []);

  const handleDelete = useCallback(() => {
    if (!activeFile) return;
    deleteFile.mutate(activeFile.id, {
      onSuccess: () => {
        toast.success('删除成功');
        setDeleteOpen(false);
        setActiveFile(null);
      },
      onError: (error) => {
        toast.error(getApiErrorMessage(error, '删除失败'));
      },
    });
  }, [activeFile, deleteFile]);

  /** 下载 */
  const handleDownload = useCallback(async (file: FileItem) => {
    if (file.type === 'folder') return;
    try {
      const result = await getDownloadUrl.mutateAsync(file.id);
      const url = result.downloadUrl;
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (error) {
      toast.error(getApiErrorMessage(error, '获取下载链接失败'));
    }
  }, [getDownloadUrl]);

  /** 分享 */
  const openShare = useCallback((file: FileItem) => {
    setActiveFile(file);
    setShareOpen(true);
  }, []);

  /** 移动 */
  const openMove = useCallback((file: FileItem) => {
    setActiveFile(file);
    setMoveOpen(true);
  }, []);

  /** 上传文件 */
  const handleUploadClick = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleFileSelect = useCallback(async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const fileArray = Array.from(files);

    if (!isAdmin) {
      const totalSize = fileArray.reduce((sum: number, f: File) => sum + f.size, 0);
      if (totalSize > remainingBytes) {
        toast.error(`剩余空间不足，无法上传。剩余 ${formatFileSize(remainingBytes)}，需要 ${formatFileSize(totalSize)}`);
        return;
      }

      const oversized = fileArray.find((f: File) => f.size > remainingBytes);
      if (oversized) {
        toast.error(`文件「${oversized.name}」超过剩余空间，无法上传`);
        return;
      }
    }

    await startUpload(fileArray);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [remainingBytes, isAdmin]);

  const startUpload = useCallback(async (fileArray: File[]) => {
    // 先添加到上传列表
    const newItems: UploadItem[] = fileArray.map((f) => ({
      id: `${f.name}-${f.size}-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      name: f.name,
      size: f.size,
      percent: 0,
      status: 'uploading',
    }));
    setUploadItems((prev) => [...prev, ...newItems]);

    // 尝试获取 dataloom（运行时注入，按需动态导入）
    let dataloom: DataloomClient | null = null;
    try {
      const mod = await import('@lark-apaas/client-toolkit/dataloom');
      const client = await (mod.getDataloom as () => Promise<unknown>)();
      dataloom = client as DataloomClient;
    } catch (error) {
      logger.warn('dataloom SDK 不可用', error);
    }

    if (!dataloom) {
      // 降级：标记为失败并提示
      setUploadItems((prev) =>
        prev.map((item) =>
          newItems.some((n) => n.id === item.id)
            ? { ...item, status: 'error', error: '上传功能需要配置存储服务' }
            : item,
        ),
      );
      toast.error('上传功能需要配置存储服务');
      return;
    }

    // 逐个上传
    for (let i = 0; i < fileArray.length; i += 1) {
      const file = fileArray[i];
      const itemId = newItems[i].id;

      try {
        const bucket = dataloom.storage.from(getDefaultBucketId());
        const { data, error } = await bucket.uploadFile(file);
        if (error || !data) {
          throw new Error(error?.message || error?.error_msg || '上传失败');
        }

        // 通知后端上传完成
        await uploadComplete.mutateAsync({
          name: file.name,
          filePath: data.file_path,
          bucketId: data.bucket_id,
          sizeBytes: file.size,
          mimeType: file.type || undefined,
        });

        setUploadItems((prev) =>
          prev.map((item) =>
            item.id === itemId ? { ...item, percent: 100, status: 'success' } : item,
          ),
        );
      } catch (error) {
        logger.error('上传失败', error);
        setUploadItems((prev) =>
          prev.map((item) =>
            item.id === itemId
              ? {
                  ...item,
                  status: 'error',
                  error: error instanceof Error ? error.message : '上传失败',
                }
              : item,
          ),
        );
      }
    }

    // 刷新文件列表和用户配额
    queryClient.invalidateQueries({ queryKey: [FILES_QUERY_KEY, parentId] });
    void refreshUser();
  }, [parentId, queryClient, uploadComplete, refreshUser]);

  /** 拖拽上传 */
  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current += 1;
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setIsDragOver(true);
    }
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current -= 1;
    if (dragCounter.current <= 0) {
      setIsDragOver(false);
      dragCounter.current = 0;
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragOver(false);
      dragCounter.current = 0;

      const files = e.dataTransfer.files;
      if (files && files.length > 0) {
        void startUpload(Array.from(files));
      }
    },
    [startUpload],
  );

  /** 排序选项变更 */
  const handleSortChange = useCallback((value: string) => {
    const [by, order] = value.split('-') as [SortBy, SortOrder];
    setSortBy(by);
    setSortOrder(order);
  }, []);

  const sortValue = `${sortBy}-${sortOrder}`;

  /** 渲染文件图标 */
  const renderFileIcon = useCallback((file: FileItem, size = 'w-5 h-5') => {
    const category = getFileCategory(file.type, file.mimeType, file.name);
    const { icon: Icon, color } = FILE_ICON_MAP[category];
    return <Icon className={`${size} ${color} flex-shrink-0`} />;
  }, []);

  return (
    <div
      className="flex flex-col h-full bg-white"
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      {/* 拖拽上传遮罩 */}
      {isDragOver && (
        <div className="fixed inset-0 z-50 bg-blue-500/10 backdrop-blur-sm flex items-center justify-center pointer-events-none">
          <div className="bg-white rounded-xl shadow-xl px-12 py-8 border-2 border-dashed border-blue-400">
            <Upload className="w-12 h-12 text-blue-500 mx-auto mb-3" />
            <p className="text-lg font-medium text-slate-700">释放以上传文件</p>
          </div>
        </div>
      )}

      {/* 存储用量条 */}
      {user && (
        <div className="px-4 sm:px-6 pt-4 pb-2 bg-slate-50 border-b border-slate-200">
          <StorageBar
            usedBytes={user.usedBytes}
            quotaBytes={user.quotaBytes}
            size="sm"
            showLabel
            showRemaining
            unlimited={isAdmin}
          />
        </div>
      )}

      {/* 顶部工具栏 */}
      <div className="h-14 border-b border-slate-200 px-4 sm:px-6 flex items-center gap-3 flex-shrink-0">
        {/* 面包屑 */}
        <div className="flex items-center min-w-0 flex-shrink-0">
          <Breadcrumb>
            <BreadcrumbList className="flex-nowrap">
              {currentPath.map((item, index) => (
                <BreadcrumbItem key={item.id ?? 'root'} className="flex-shrink-0">
                  {index === currentPath.length - 1 ? (
                    <BreadcrumbPage className="text-sm truncate max-w-[120px] sm:max-w-none">
                      {item.name}
                    </BreadcrumbPage>
                  ) : (
                    <>
                      <BreadcrumbLink
                        onClick={() => handleBreadcrumbClick(index)}
                        className="cursor-pointer truncate max-w-[100px]"
                      >
                        {item.name}
                      </BreadcrumbLink>
                      <BreadcrumbSeparator>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </BreadcrumbSeparator>
                    </>
                  )}
                </BreadcrumbItem>
              ))}
            </BreadcrumbList>
          </Breadcrumb>
        </div>

        {/* 搜索框 */}
        <div className="flex-1 max-w-sm ml-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="搜索文件..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>

        {/* 排序下拉 */}
        <div className="hidden sm:block">
          <Select value={sortValue} onValueChange={handleSortChange}>
            <SelectTrigger size="sm" className="w-[140px]">
              <div className="flex items-center gap-1">
                <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                <SelectValue />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name-asc">名称 A→Z</SelectItem>
              <SelectItem value="name-desc">名称 Z→A</SelectItem>
              <SelectItem value="sizeBytes-desc">大小 大→小</SelectItem>
              <SelectItem value="sizeBytes-asc">大小 小→大</SelectItem>
              <SelectItem value="updatedAt-desc">修改时间 新→旧</SelectItem>
              <SelectItem value="updatedAt-asc">修改时间 旧→新</SelectItem>
              <SelectItem value="type-asc">类型</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 视图切换 */}
        <div className="hidden sm:flex items-center border rounded-md p-0.5">
          <Button
            variant="ghost"
            size="icon"
            className={`h-7 w-7 ${viewMode === 'list' ? 'bg-slate-100' : ''}`}
            onClick={() => setViewMode('list')}
            aria-label="列表视图"
          >
            <List className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className={`h-7 w-7 ${viewMode === 'grid' ? 'bg-slate-100' : ''}`}
            onClick={() => setViewMode('grid')}
            aria-label="网格视图"
          >
            <Grid3x3 className="w-4 h-4" />
          </Button>
        </div>

        {/* 新建文件夹 */}
        <Button variant="outline" size="sm" onClick={() => setNewFolderOpen(true)}>
          <FolderPlus className="w-4 h-4" />
          <span className="hidden sm:inline">新建文件夹</span>
        </Button>

        {/* 上传文件 */}
        <Button size="sm" onClick={handleUploadClick}>
          <Upload className="w-4 h-4" />
          <span className="hidden sm:inline">上传文件</span>
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => handleFileSelect(e.target.files)}
        />
      </div>

      {/* 文件列表区 */}
      <div className="flex-1 overflow-auto p-4 sm:p-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-full text-slate-400">加载中...</div>
        ) : isError ? (
          <div className="flex items-center justify-center h-full text-red-400">加载失败，请刷新重试</div>
        ) : fileList.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <Empty className="max-w-sm border-none">
              <EmptyMedia variant="icon">
                <FolderOpen className="w-6 h-6" />
              </EmptyMedia>
              <EmptyHeader>
                <EmptyTitle>此文件夹为空</EmptyTitle>
                <EmptyDescription>
                  {debouncedSearch ? '没有找到匹配的文件，试试其他关键词。' : '点击上方按钮上传文件或新建文件夹。'}
                </EmptyDescription>
              </EmptyHeader>
            </Empty>
          </div>
        ) : viewMode === 'list' ? (
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead>名称</TableHead>
                <TableHead className="w-24 hidden md:table-cell">大小</TableHead>
                <TableHead className="w-24 hidden sm:table-cell">类型</TableHead>
                <TableHead className="w-40 hidden lg:table-cell">修改时间</TableHead>
                <TableHead className="w-16 text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {fileList.map((file) => (
                <TableRow
                  key={file.id}
                  className="h-12 cursor-pointer group"
                  onClick={() => {
                    if (file.type === 'folder') {
                      handleEnterFolder(file);
                    }
                  }}
                >
                  <TableCell>
                    <div className="flex items-center gap-2 min-w-0">
                      {renderFileIcon(file)}
                      <span className="truncate text-slate-700">{file.name}</span>
                    </div>
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-slate-500 text-sm">
                    {file.type === 'folder' ? '-' : formatFileSize(file.sizeBytes)}
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-slate-500 text-sm">
                    {file.type === 'folder' ? '文件夹' : file.mimeType?.split('/')[0] || '文件'}
                  </TableCell>
                  <TableCell className="hidden lg:table-cell text-slate-500 text-sm">
                    {formatDateTime(file.updatedAt)}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={(e) => e.stopPropagation()}
                          aria-label="更多操作"
                        >
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {file.type === 'file' && (
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDownload(file);
                            }}
                          >
                            <Download className="w-4 h-4" />
                            下载
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation();
                            openRename(file);
                          }}
                        >
                          <Pencil className="w-4 h-4" />
                          重命名
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation();
                            openMove(file);
                          }}
                        >
                          <ArrowRightLeft className="w-4 h-4" />
                          移动
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation();
                            openShare(file);
                          }}
                        >
                          <Share2 className="w-4 h-4" />
                          分享
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          variant="destructive"
                          onClick={(e) => {
                            e.stopPropagation();
                            openDelete(file);
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                          删除
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <div
            className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3"
            data-ai-section-type="card-list"
          >
            {fileList.map((file) => (
              <div
                key={file.id}
                className="group relative bg-white border border-slate-200 rounded-lg p-3 hover:border-blue-300 hover:shadow-sm transition-all cursor-pointer"
                onClick={() => {
                  if (file.type === 'folder') {
                    handleEnterFolder(file);
                  }
                }}
              >
                <div className="aspect-square flex items-center justify-center mb-2 bg-slate-50 rounded-md">
                  {getFileCategory(file.type, file.mimeType, file.name) === 'image' && file.mimeType ? (
                    <div className="w-full h-full flex items-center justify-center text-slate-400">
                      {renderFileIcon(file, 'w-12 h-12')}
                    </div>
                  ) : (
                    renderFileIcon(file, 'w-12 h-12')
                  )}
                </div>
                <div className="text-sm text-slate-700 truncate">{file.name}</div>
                <div className="text-xs text-slate-400 mt-0.5">
                  {file.type === 'folder' ? '-' : formatFileSize(file.sizeBytes)}
                </div>
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 bg-white/90 backdrop-blur-sm border border-slate-200"
                        onClick={(e) => e.stopPropagation()}
                        aria-label="更多操作"
                      >
                        <MoreVertical className="w-3.5 h-3.5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      {file.type === 'file' && (
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDownload(file);
                          }}
                        >
                          <Download className="w-4 h-4" />
                          下载
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem
                        onClick={(e) => {
                          e.stopPropagation();
                          openRename(file);
                        }}
                      >
                        <Pencil className="w-4 h-4" />
                        重命名
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={(e) => {
                          e.stopPropagation();
                          openMove(file);
                        }}
                      >
                        <ArrowRightLeft className="w-4 h-4" />
                        移动
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={(e) => {
                          e.stopPropagation();
                          openShare(file);
                        }}
                      >
                        <Share2 className="w-4 h-4" />
                        分享
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        variant="destructive"
                        onClick={(e) => {
                          e.stopPropagation();
                          openDelete(file);
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                        删除
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 新建文件夹对话框 */}
      <Dialog open={newFolderOpen} onOpenChange={setNewFolderOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-blue-500" />
              新建文件夹
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="folder-name">文件夹名称</Label>
            <Input
              id="folder-name"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              placeholder="输入文件夹名称"
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleCreateFolder();
              }}
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewFolderOpen(false)}>
              取消
            </Button>
            <Button onClick={handleCreateFolder} disabled={createFolder.isPending}>
              {createFolder.isPending ? '创建中...' : '创建'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 重命名对话框 */}
      <Dialog open={renameOpen} onOpenChange={setRenameOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="w-5 h-5 text-blue-500" />
              重命名
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="rename-name">新名称</Label>
            <Input
              id="rename-name"
              value={renameName}
              onChange={(e) => setRenameName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleRename();
              }}
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRenameOpen(false)}>
              取消
            </Button>
            <Button onClick={handleRename} disabled={renameFile.isPending}>
              {renameFile.isPending ? '保存中...' : '保存'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 删除确认对话框 */}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除 &quot;<span className="font-medium text-slate-700">{activeFile?.name}</span>&quot;{' '}
              吗？此操作不可撤销。
              {activeFile?.type === 'folder' && '文件夹内的所有文件也会被删除。'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-500 hover:bg-red-600"
              onClick={handleDelete}
              disabled={deleteFile.isPending}
            >
              {deleteFile.isPending ? '删除中...' : '删除'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 分享对话框 */}
      <ShareDialog open={shareOpen} onOpenChange={setShareOpen} file={activeFile} />

      {/* 移动对话框 */}
      <MoveDialog open={moveOpen} onOpenChange={setMoveOpen} file={activeFile} />

      {/* 上传进度面板 */}
      <UploadProgressPanel
        items={uploadItems}
        onClose={() => setUploadItems([])}
      />
    </div>
  );
}
