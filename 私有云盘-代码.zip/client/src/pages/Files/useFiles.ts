import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { files, shares } from '@client/src/api/index';
import type {
  FileItem,
  FileListResponse,
  CreateShareResponse,
} from '@shared/api.interface';

/** 文件列表查询 key */
export const FILES_QUERY_KEY = 'files';

export function useFileList(params: {
  parentId: string | null;
  sortBy: string;
  sortOrder: string;
  search: string;
}) {
  return useQuery<FileListResponse>({
    queryKey: [FILES_QUERY_KEY, params.parentId, params.sortBy, params.sortOrder, params.search],
    queryFn: () => files.list(params),
  });
}

export function useCreateFolder(parentId: string | null) {
  const queryClient = useQueryClient();
  return useMutation<FileItem, unknown, string>({
    mutationFn: (name: string) => files.createFolder(name, parentId),
    retry: false,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [FILES_QUERY_KEY, parentId] });
    },
  });
}

export function useRenameFile(parentId: string | null) {
  const queryClient = useQueryClient();
  return useMutation<FileItem, unknown, { id: string; name: string }>({
    mutationFn: ({ id, name }) => files.rename(id, name),
    retry: false,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [FILES_QUERY_KEY, parentId] });
    },
  });
}

export function useMoveFile(parentId: string | null) {
  const queryClient = useQueryClient();
  return useMutation<FileItem, unknown, { id: string; targetParentId: string | null }>({
    mutationFn: ({ id, targetParentId }) => files.move(id, targetParentId),
    retry: false,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [FILES_QUERY_KEY, parentId] });
    },
  });
}

export function useDeleteFile(parentId: string | null) {
  const queryClient = useQueryClient();
  return useMutation<void, unknown, string>({
    mutationFn: (id: string) => files.remove(id),
    retry: false,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [FILES_QUERY_KEY, parentId] });
    },
  });
}

export function useUploadComplete(parentId: string | null) {
  const queryClient = useQueryClient();
  return useMutation<
    FileItem,
    unknown,
    { name: string; filePath: string; bucketId: string; sizeBytes: number; mimeType?: string }
  >({
    mutationFn: (data) => files.uploadComplete({ ...data, parentId }),
    retry: false,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [FILES_QUERY_KEY, parentId] });
    },
  });
}

export function useGetDownloadUrl() {
  return useMutation<{ downloadUrl: string; filePath: string; bucketId: string }, unknown, string>({
    mutationFn: (id: string) => files.getDownloadUrl(id),
    retry: false,
  });
}

export function useCreateShare() {
  return useMutation<
    CreateShareResponse,
    unknown,
    { fileId: string; password?: string; expiresAt?: string | null; allowDownload?: boolean }
  >({
    mutationFn: (data) => shares.create(data),
    retry: false,
  });
}
