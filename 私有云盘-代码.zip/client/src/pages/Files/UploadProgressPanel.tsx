import { Upload, CheckCircle, XCircle } from 'lucide-react';
import { Progress } from '@client/src/components/ui/progress';
import { formatFileSize } from './fileUtils';

export type UploadStatus = 'uploading' | 'success' | 'error';

export interface UploadItem {
  id: string;
  name: string;
  size: number;
  percent: number;
  status: UploadStatus;
  error?: string;
}

interface UploadProgressPanelProps {
  items: UploadItem[];
  onClose: () => void;
}

export function UploadProgressPanel({ items, onClose }: UploadProgressPanelProps) {
  if (items.length === 0) return null;

  const successCount = items.filter((i) => i.status === 'success').length;
  const errorCount = items.filter((i) => i.status === 'error').length;
  const uploadingCount = items.filter((i) => i.status === 'uploading').length;
  const allDone = uploadingCount === 0;

  return (
    <div className="fixed bottom-4 right-4 w-80 bg-white border border-slate-200 rounded-lg shadow-lg z-40">
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-100">
        <div className="flex items-center gap-2 text-sm font-medium text-slate-700">
          <Upload className="w-4 h-4 text-blue-500" />
          <span>上传任务</span>
          <span className="text-xs text-slate-400">
            ({successCount + errorCount}/{items.length})
          </span>
        </div>
        {allDone && (
          <button
            type="button"
            onClick={onClose}
            className="text-xs text-slate-400 hover:text-slate-600"
          >
            关闭
          </button>
        )}
      </div>
      <div className="max-h-64 overflow-y-auto">
        {items.map((item) => (
          <div key={item.id} className="px-4 py-2 border-b border-slate-50 last:border-b-0">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-slate-700 truncate flex-1 mr-2">
                {item.name}
              </span>
              <span className="text-xs text-slate-400 flex-shrink-0">
                {item.status === 'success' && (
                  <span className="flex items-center gap-1 text-green-500">
                    <CheckCircle className="w-3.5 h-3.5" />
                    完成
                  </span>
                )}
                {item.status === 'error' && (
                  <span className="flex items-center gap-1 text-red-500">
                    <XCircle className="w-3.5 h-3.5" />
                    失败
                  </span>
                )}
                {item.status === 'uploading' && `${Math.round(item.percent)}%`}
              </span>
            </div>
            {item.status === 'uploading' && (
              <Progress value={item.percent} className="h-1" />
            )}
            <div className="text-xs text-slate-400 mt-0.5">
              {formatFileSize(item.size)}
              {item.error && <span className="text-red-400"> · {item.error}</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
