import { useState } from 'react';
import { FolderOpen, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import { Button } from '@client/src/components/ui/button';
import { useFileList, useMoveFile } from './useFiles';
import type { FileItem } from '@shared/api.interface';
import { getApiErrorMessage } from '@client/src/lib/api-error';

interface MoveDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  file: FileItem | null;
}

interface PathItem {
  id: string | null;
  name: string;
}

export function MoveDialog({ open, onOpenChange, file }: MoveDialogProps) {
  const [currentParentId, setCurrentParentId] = useState<string | null>(null);
  const [path, setPath] = useState<PathItem[]>([{ id: null, name: '根目录' }]);

  const { data, isLoading } = useFileList({
    parentId: currentParentId,
    sortBy: 'name',
    sortOrder: 'asc',
    search: '',
  });

  const moveFile = useMoveFile(file?.parentId ?? null);

  const folders = (data?.items ?? []).filter((item) => item.type === 'folder');

  const handleEnterFolder = (folder: FileItem) => {
    setCurrentParentId(folder.id);
    setPath([...path, { id: folder.id, name: folder.name }]);
  };

  const handleBreadcrumbClick = (index: number) => {
    const target = path[index];
    setCurrentParentId(target.id);
    setPath(path.slice(0, index + 1));
  };

  const handleMove = () => {
    if (!file) return;
    // 不能移动到自身或自身的子目录（简化：只检查是否和原位置相同）
    if (file.parentId === currentParentId) {
      toast.info('目标目录与当前目录相同');
      return;
    }
    moveFile.mutate(
      { id: file.id, targetParentId: currentParentId },
      {
        onSuccess: () => {
          toast.success('移动成功');
          onOpenChange(false);
        },
        onError: (error) => {
          toast.error(getApiErrorMessage(error, '移动失败'));
        },
      },
    );
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (newOpen) {
      setCurrentParentId(null);
      setPath([{ id: null, name: '根目录' }]);
    }
    onOpenChange(newOpen);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>移动到</DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          {/* 面包屑 */}
          <div className="flex items-center flex-wrap gap-1 text-sm">
            {path.map((item, index) => (
              <div key={item.id ?? 'root'} className="flex items-center gap-1">
                {index > 0 && <ChevronRight className="w-3 h-3 text-slate-400" />}
                <button
                  type="button"
                  onClick={() => handleBreadcrumbClick(index)}
                  className={`px-2 py-1 rounded hover:bg-slate-100 ${
                    index === path.length - 1 ? 'text-slate-800 font-medium' : 'text-slate-500'
                  }`}
                >
                  {item.name}
                </button>
              </div>
            ))}
          </div>

          {/* 文件夹列表 */}
          <div className="border rounded-md max-h-64 overflow-y-auto">
            {isLoading ? (
              <div className="p-8 text-center text-sm text-slate-500">加载中...</div>
            ) : folders.length === 0 ? (
              <div className="p-8 text-center text-sm text-slate-500">此目录下没有子文件夹</div>
            ) : (
              <ul className="divide-y">
                {folders.map((folder) => (
                  <li key={folder.id}>
                    <button
                      type="button"
                      onClick={() => handleEnterFolder(folder)}
                      className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-slate-50 text-left"
                    >
                      <FolderOpen className="w-4 h-4 text-blue-500 flex-shrink-0" />
                      <span className="truncate">{folder.name}</span>
                      <ChevronRight className="w-4 h-4 text-slate-400 ml-auto flex-shrink-0" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => handleOpenChange(false)}>
            取消
          </Button>
          <Button onClick={handleMove} disabled={moveFile.isPending}>
            {moveFile.isPending ? '移动中...' : '确认移动'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
