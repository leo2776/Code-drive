import {
  Folder,
  FileText,
  Image,
  Film,
  Music,
  File,
  type LucideIcon,
} from 'lucide-react';

/** 文件分类 */
export type FileCategory = 'folder' | 'image' | 'video' | 'audio' | 'document' | 'other';

/**
 * 根据文件名和 MIME 类型推断文件分类
 */
export function getFileCategory(
  type: 'file' | 'folder',
  mimeType: string | null,
  name: string,
): FileCategory {
  if (type === 'folder') return 'folder';

  const mime = mimeType?.toLowerCase() ?? '';
  const ext = name.split('.').pop()?.toLowerCase() ?? '';

  if (mime.startsWith('image/') || ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'ico'].includes(ext)) {
    return 'image';
  }
  if (mime.startsWith('video/') || ['mp4', 'mov', 'avi', 'mkv', 'webm', 'flv', 'wmv'].includes(ext)) {
    return 'video';
  }
  if (mime.startsWith('audio/') || ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'].includes(ext)) {
    return 'audio';
  }
  if (
    mime.includes('pdf') ||
    mime.includes('word') ||
    mime.includes('excel') ||
    mime.includes('spreadsheet') ||
    mime.includes('presentation') ||
    mime.includes('text/') ||
    ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'md', 'csv', 'json', 'xml', 'html'].includes(ext)
  ) {
    return 'document';
  }
  return 'other';
}

/** 文件图标映射 */
export const FILE_ICON_MAP: Record<FileCategory, { icon: LucideIcon; color: string }> = {
  folder: { icon: Folder, color: 'text-blue-500' },
  image: { icon: Image, color: 'text-green-500' },
  video: { icon: Film, color: 'text-purple-500' },
  audio: { icon: Music, color: 'text-pink-500' },
  document: { icon: FileText, color: 'text-blue-500' },
  other: { icon: File, color: 'text-slate-400' },
};

/**
 * 格式化文件大小
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  const val = bytes / Math.pow(1024, i);
  return `${val.toFixed(val < 10 && i > 0 ? 2 : val < 100 ? 1 : 0)} ${units[i]}`;
}

/**
 * 格式化日期时间为 YYYY-MM-DD HH:mm
 */
export function formatDateTime(isoString: string): string {
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return isoString;
  const pad = (n: number): string => n.toString().padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
