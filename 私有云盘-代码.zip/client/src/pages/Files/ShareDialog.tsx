import { useState } from 'react';
import { Copy, Check, Share2, Calendar, Lock, Download } from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Switch } from '@client/src/components/ui/switch';
import { Label } from '@client/src/components/ui/label';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import { Calendar as CalendarComponent } from '@client/src/components/ui/calendar';
import { useCreateShare } from './useFiles';
import { formatDateTime } from './fileUtils';
import type { FileItem } from '@shared/api.interface';
import { getApiErrorMessage } from '@client/src/lib/api-error';

interface ShareDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  file: FileItem | null;
}

export function ShareDialog({ open, onOpenChange, file }: ShareDialogProps) {
  const [password, setPassword] = useState('');
  const [expiresAt, setExpiresAt] = useState<Date | null>(null);
  const [allowDownload, setAllowDownload] = useState(true);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const createShare = useCreateShare();

  const handleReset = () => {
    setPassword('');
    setExpiresAt(null);
    setAllowDownload(true);
    setShareUrl(null);
    setCopied(false);
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      handleReset();
    }
    onOpenChange(newOpen);
  };

  const handleGenerate = () => {
    if (!file) return;
    createShare.mutate(
      {
        fileId: file.id,
        password: password || undefined,
        expiresAt: expiresAt ? expiresAt.toISOString() : null,
        allowDownload,
      },
      {
        onSuccess: (data) => {
          setShareUrl(data.shareUrl);
          toast.success('分享链接已生成');
        },
        onError: (error) => {
          toast.error(getApiErrorMessage(error, '生成分享链接失败'));
        },
      },
    );
  };

  const handleCopy = async () => {
    if (!shareUrl) return;
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      toast.success('链接已复制');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('复制失败，请手动复制');
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-blue-500" />
            分享文件
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-3 bg-slate-50 rounded-md text-sm text-slate-700">
            <span className="font-medium">{file?.name}</span>
          </div>

          {shareUrl ? (
            <div className="space-y-3">
              <div className="text-sm font-medium text-slate-700">分享链接</div>
              <div className="flex gap-2">
                <Input value={shareUrl} readOnly className="flex-1 text-xs" />
                <Button size="sm" onClick={handleCopy} variant="outline">
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
              <div className="text-xs text-slate-500">
                {password && <p>密码：{password}</p>}
                {expiresAt && <p>过期时间：{formatDateTime(expiresAt.toISOString())}</p>}
                <p>允许下载：{allowDownload ? '是' : '否'}</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Lock className="w-4 h-4 text-slate-500" />
                  <Label htmlFor="share-password">访问密码（可选）</Label>
                </div>
                <Input
                  id="share-password"
                  type="text"
                  placeholder="留空表示无需密码"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-slate-500" />
                  <Label>过期时间（可选）</Label>
                </div>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      {expiresAt ? formatDateTime(expiresAt.toISOString()) : '选择日期，留空表示永不过期'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <CalendarComponent
                      mode="single"
                      selected={expiresAt ?? undefined}
                      onSelect={(date) => setExpiresAt(date ?? null)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                {expiresAt && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setExpiresAt(null)}
                    className="text-xs text-slate-500 h-auto py-1"
                  >
                    清除日期
                  </Button>
                )}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  <Download className="w-4 h-4 text-slate-500" />
                  <Label htmlFor="share-download">允许下载</Label>
                </div>
                <Switch
                  id="share-download"
                  checked={allowDownload}
                  onCheckedChange={setAllowDownload}
                />
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          {shareUrl ? (
            <Button variant="outline" onClick={() => handleOpenChange(false)}>
              关闭
            </Button>
          ) : (
            <>
              <Button variant="outline" onClick={() => handleOpenChange(false)}>
                取消
              </Button>
              <Button
                onClick={handleGenerate}
                disabled={createShare.isPending}
              >
                {createShare.isPending ? '生成中...' : '生成分享链接'}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
