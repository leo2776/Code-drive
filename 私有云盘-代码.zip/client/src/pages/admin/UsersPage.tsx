import { useState, useCallback, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import {
  Search,
  Plus,
  Edit,
  Trash2,
  Ban,
  CheckCircle,
  RotateCcw,
  Upload,
  Share2,
  Key,
  ChevronLeft,
  ChevronRight,
  Loader2,
} from 'lucide-react';

import { users as usersApi } from '@client/src/api';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import { Badge } from '@client/src/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@client/src/components/ui/alert-dialog';
import { Switch } from '@client/src/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  Field,
  FieldLabel,
  FieldContent,
  FieldError,
} from '@client/src/components/ui/field';
import { formatFileSize } from '@client/src/utils/format';
import { toBytes } from '@client/src/utils/format';
import { getApiErrorMessage } from '@client/src/lib/api-error';
import { StorageBar } from '@client/src/components/ui/storage-bar';
import { USER_ROLE_LABELS } from '@shared/api.interface';
import type { UserInfo, UserRole } from '@shared/api.interface';

const PAGE_SIZE = 10;

const userFormSchema = z.object({
  username: z.string().min(1, { message: '请输入用户名' }),
  password: z.string().optional(),
  role: z.enum(['admin', 'user']),
  quotaValue: z.number().min(0.001, { message: '配额必须大于 0' }),
  quotaUnit: z.enum(['MB', 'GB', 'TB']),
  canUpload: z.boolean(),
  canShare: z.boolean(),
  canUseApi: z.boolean(),
  allowedFileTypes: z.string().optional(),
});

const DEFAULT_QUOTA_TB = 1;

function useDebouncedSearch(onSearch: (value: string) => void, delay = 300) {
  const [timer, setTimer] = useState<ReturnType<typeof setTimeout> | null>(null);

  return useCallback(
    (value: string) => {
      if (timer) clearTimeout(timer);
      const t = setTimeout(() => onSearch(value), delay);
      setTimer(t);
    },
    [timer, onSearch, delay]
  );
}

export default function UsersPage() {
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserInfo | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<UserInfo | null>(null);

  const debouncedSearch = useDebouncedSearch((value: string) => {
    setSearch(value);
    setPage(1);
  }, 300);

  const { data, isLoading } = useQuery({
    queryKey: ['users', { page, pageSize: PAGE_SIZE, search }],
    queryFn: () =>
      usersApi.list({ page, pageSize: PAGE_SIZE, search: search || undefined }),
  });

  const createMutation = useMutation({
    mutationFn: (formData: z.infer<typeof userFormSchema>) => {
      const quotaBytes = toBytes(formData.quotaValue, formData.quotaUnit);
      return usersApi.create({
        username: formData.username,
        password: formData.password,
        role: formData.role,
        quotaBytes,
        canUpload: formData.canUpload,
        canShare: formData.canShare,
        canUseApi: formData.canUseApi,
        allowedFileTypes: formData.allowedFileTypes
          ? formData.allowedFileTypes
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean)
          : undefined,
      });
    },
    onSuccess: () => {
      toast.success('用户创建成功');
      setDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
    onError: (error) => {
      toast.error(getApiErrorMessage(error, '创建用户失败'));
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, formData }: { id: string; formData: z.infer<typeof userFormSchema> }) => {
      const quotaBytes = toBytes(formData.quotaValue, formData.quotaUnit);
      const payload: Record<string, unknown> = {
        role: formData.role,
        quotaBytes,
        canUpload: formData.canUpload,
        canShare: formData.canShare,
        canUseApi: formData.canUseApi,
        allowedFileTypes: formData.allowedFileTypes
          ? formData.allowedFileTypes
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean)
          : [],
      };
      if (formData.password && formData.password.length > 0) {
        payload.password = formData.password;
      }
      return usersApi.update(id, payload);
    },
    onSuccess: () => {
      toast.success('用户更新成功');
      setDialogOpen(false);
      setEditingUser(null);
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
    onError: (error) => {
      toast.error(getApiErrorMessage(error, '更新用户失败'));
    },
  });

  const toggleActiveMutation = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) =>
      usersApi.update(id, { isActive }),
    onSuccess: () => {
      toast.success('状态已更新');
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
    onError: (error) => {
      toast.error(getApiErrorMessage(error, '操作失败'));
    },
  });

  const resetPasswordMutation = useMutation({
    mutationFn: ({ id, password }: { id: string; password: string }) =>
      usersApi.update(id, { password }),
    onSuccess: () => {
      toast.success('密码已重置');
    },
    onError: (error) => {
      toast.error(getApiErrorMessage(error, '重置密码失败'));
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => usersApi.remove(id),
    onSuccess: () => {
      toast.success('用户已删除');
      setDeleteTarget(null);
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
    onError: (error) => {
      toast.error(getApiErrorMessage(error, '删除用户失败'));
    },
  });

  const handleOpenCreate = () => {
    setEditingUser(null);
    setDialogOpen(true);
  };

  const handleOpenEdit = (user: UserInfo) => {
    setEditingUser(user);
    setDialogOpen(true);
  };

  const handleResetPassword = (user: UserInfo) => {
    const newPassword = prompt('请输入新密码（至少 6 位）');
    if (newPassword === null) return;
    if (newPassword.length < 6) {
      toast.error('密码至少 6 位');
      return;
    }
    resetPasswordMutation.mutate({ id: user.id, password: newPassword });
  };

  const items: UserInfo[] = data?.items ?? [];
  const total: number = data?.total ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold mb-6">用户管理</h1>

      {/* 工具栏 */}
      <div className="flex items-center justify-between mb-4 gap-4 flex-wrap">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="搜索用户名..."
            value={searchInput}
            onChange={(e) => {
              setSearchInput(e.target.value);
              debouncedSearch(e.target.value);
            }}
            className="pl-9"
          />
        </div>
        <Button onClick={handleOpenCreate}>
          <Plus className="w-4 h-4" />
          新建用户
        </Button>
      </div>

      {/* 表格 */}
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>用户名</TableHead>
              <TableHead>角色</TableHead>
              <TableHead>存储使用</TableHead>
              <TableHead>状态</TableHead>
              <TableHead>权限</TableHead>
              <TableHead className="text-right">操作</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                  <Loader2 className="w-5 h-5 animate-spin mx-auto" />
                </TableCell>
              </TableRow>
            ) : items.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                  暂无用户
                </TableCell>
              </TableRow>
            ) : (
              items.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium text-slate-800">
                    {user.username}
                  </TableCell>
                  <TableCell>
                    <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                      {USER_ROLE_LABELS[user.role]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm text-slate-700">
                      {formatFileSize(user.usedBytes)} / {user.role === 'admin' ? '无限制' : formatFileSize(user.quotaBytes)}
                    </div>
                    <div className="w-32 h-1.5 bg-slate-100 rounded-full mt-1 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${user.role === 'admin' ? 'bg-slate-300 w-full' : 'bg-blue-500'}`}
                        style={{
                          width: user.role === 'admin' ? '100%' : `${Math.min(100, (user.usedBytes / user.quotaBytes) * 100)}%`,
                        }}
                      />
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={user.isActive ? 'default' : 'secondary'}
                      className={
                        user.isActive
                          ? 'bg-emerald-500 border-emerald-500'
                          : 'bg-slate-200 text-slate-600 border-slate-200'
                      }
                    >
                      {user.isActive ? '启用' : '禁用'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div
                        title={user.canUpload ? '允许上传' : '禁止上传'}
                        className={user.canUpload ? 'text-emerald-600' : 'text-slate-300'}
                      >
                        <Upload className="w-4 h-4" />
                      </div>
                      <div
                        title={user.canShare ? '允许分享' : '禁止分享'}
                        className={user.canShare ? 'text-emerald-600' : 'text-slate-300'}
                      >
                        <Share2 className="w-4 h-4" />
                      </div>
                      <div
                        title={user.canUseApi ? '允许 API' : '禁止 API'}
                        className={user.canUseApi ? 'text-emerald-600' : 'text-slate-300'}
                      >
                        <Key className="w-4 h-4" />
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleOpenEdit(user)}
                        aria-label={`编辑用户 ${user.username}`}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleResetPassword(user)}
                        aria-label={`重置 ${user.username} 的密码`}
                      >
                        <RotateCcw className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() =>
                          toggleActiveMutation.mutate({ id: user.id, isActive: !user.isActive })
                        }
                        aria-label={user.isActive ? `禁用用户 ${user.username}` : `启用用户 ${user.username}`}
                      >
                        {user.isActive ? (
                          <Ban className="w-4 h-4 text-amber-600" />
                        ) : (
                          <CheckCircle className="w-4 h-4 text-emerald-600" />
                        )}
                      </Button>
                      <AlertDialog
                        open={deleteTarget?.id === user.id}
                        onOpenChange={(open) => {
                          if (!open) setDeleteTarget(null);
                        }}
                      >
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setDeleteTarget(user)}
                            aria-label={`删除用户 ${user.username}`}
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>确认删除用户</AlertDialogTitle>
                            <AlertDialogDescription>
                              确定要删除用户「{deleteTarget?.username}」吗？
                              此操作不可恢复，用户的所有文件和分享记录也会被清除。
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>取消</AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-destructive hover:bg-destructive/90"
                              onClick={() => {
                                if (deleteTarget) {
                                  deleteMutation.mutate(deleteTarget.id);
                                }
                              }}
                            >
                              {deleteMutation.isPending && (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              )}
                              确认删除
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* 分页 */}
      <div className="flex items-center justify-between mt-4">
        <div className="text-sm text-slate-500">
          共 {total} 条，第 {page} / {totalPages} 页
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page <= 1}
          >
            <ChevronLeft className="w-4 h-4" />
            上一页
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
          >
            下一页
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* 新建/编辑对话框 */}
      <UserFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        editingUser={editingUser}
        onSubmit={(formData) => {
          if (editingUser) {
            updateMutation.mutate({ id: editingUser.id, formData });
          } else {
            createMutation.mutate(formData);
          }
        }}
        isSubmitting={createMutation.isPending || updateMutation.isPending}
      />
    </div>
  );
}

interface UserFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingUser: UserInfo | null;
  onSubmit: (data: z.infer<typeof userFormSchema>) => void;
  isSubmitting: boolean;
}

function UserFormDialog({
  open,
  onOpenChange,
  editingUser,
  onSubmit,
  isSubmitting,
}: UserFormDialogProps) {
  const isEdit = !!editingUser;

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<z.infer<typeof userFormSchema>>({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      username: '',
      password: '',
      role: 'user' as UserRole,
      quotaValue: DEFAULT_QUOTA_TB,
      quotaUnit: 'TB' as const,
      canUpload: true,
      canShare: true,
      canUseApi: true,
      allowedFileTypes: '',
    },
  });

  // 填充编辑/新建表单数据
  useEffect(() => {
    if (!open) return;
    if (isEdit && editingUser) {
      const bytes = editingUser.quotaBytes;
      const tb = bytes / (1024 * 1024 * 1024 * 1024);
      const gb = bytes / (1024 * 1024 * 1024);
      const mb = bytes / (1024 * 1024);

      let value: number;
      let unit: 'MB' | 'GB' | 'TB';
      if (tb >= 1) {
        value = Number(tb.toFixed(2));
        unit = 'TB';
      } else if (gb >= 1) {
        value = Number(gb.toFixed(2));
        unit = 'GB';
      } else {
        value = Math.round(mb);
        unit = 'MB';
      }

      reset({
        username: editingUser.username,
        password: '',
        role: editingUser.role,
        quotaValue: value,
        quotaUnit: unit,
        canUpload: editingUser.canUpload,
        canShare: editingUser.canShare,
        canUseApi: editingUser.canUseApi,
        allowedFileTypes: editingUser.allowedFileTypes
          ? editingUser.allowedFileTypes.join(', ')
          : '',
      });
    } else {
      reset({
        username: '',
        password: '',
        role: 'user',
        quotaValue: DEFAULT_QUOTA_TB,
        quotaUnit: 'TB',
        canUpload: true,
        canShare: true,
        canUseApi: true,
        allowedFileTypes: '',
      });
    }
  }, [open, isEdit, editingUser, reset]);

  // 监听值用于 Switch
  const canUpload = watch('canUpload');
  const canShare = watch('canShare');
  const canUseApi = watch('canUseApi');
  const role = watch('role');
  const isAdmin = role === 'admin';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>{isEdit ? '编辑用户' : '新建用户'}</DialogTitle>
          <DialogDescription>
            {isEdit ? '修改用户信息，留空密码表示不修改' : '填写用户基本信息'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Field>
              <FieldLabel>用户名</FieldLabel>
              <FieldContent>
                <Input
                  type="text"
                  placeholder="请输入用户名"
                  {...register('username')}
                  aria-invalid={!!errors.username}
                  disabled={isEdit}
                />
                <FieldError errors={[errors.username]} />
              </FieldContent>
            </Field>

            <Field>
              <FieldLabel>角色</FieldLabel>
              <FieldContent>
                <Select
                  value={role}
                  onValueChange={(val) => setValue('role', val as UserRole)}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="选择角色" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">管理员</SelectItem>
                    <SelectItem value="user">普通用户</SelectItem>
                  </SelectContent>
                </Select>
              </FieldContent>
            </Field>
          </div>

          <Field>
            <FieldLabel>
              密码{isEdit && <span className="text-slate-400 font-normal">（留空表示不修改）</span>}
            </FieldLabel>
            <FieldContent>
              <Input
                type="password"
                placeholder={isEdit ? '留空表示不修改密码' : '请输入密码（至少 6 位）'}
                {...register('password')}
                aria-invalid={!!errors.password}
              />
              <FieldError errors={[errors.password]} />
            </FieldContent>
          </Field>

          <div className="grid grid-cols-3 gap-4">
            <Field className="col-span-2">
              <FieldLabel>存储配额</FieldLabel>
              <FieldContent>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    min={1}
                    {...register('quotaValue', { valueAsNumber: true })}
                    aria-invalid={!!errors.quotaValue}
                  />
                  <Select
                    value={watch('quotaUnit')}
                    onValueChange={(val) =>
                      setValue('quotaUnit', val as 'MB' | 'GB' | 'TB')
                    }
                  >
                    <SelectTrigger className="w-24 flex-shrink-0">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MB">MB</SelectItem>
                      <SelectItem value="GB">GB</SelectItem>
                      <SelectItem value="TB">TB</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <FieldError errors={[errors.quotaValue]} />
              </FieldContent>
            </Field>
          </div>

          {isEdit && editingUser && (
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <div className="text-sm font-medium text-slate-700 mb-2">当前存储使用</div>
              <StorageBar
                usedBytes={editingUser.usedBytes}
                quotaBytes={editingUser.quotaBytes}
                size="sm"
                showLabel
                showRemaining
                unlimited={editingUser.role === 'admin'}
              />
            </div>
          )}

          {/* 权限开关 */}
          <div className="space-y-3 pt-2">
            <div className="text-sm font-medium text-slate-700">权限设置</div>
            <div className="space-y-2">
              <div className="flex items-center justify-between py-2 border-b border-slate-100">
                <div>
                  <div className="text-sm font-medium text-slate-800 flex items-center gap-2">
                    <Upload className="w-4 h-4 text-slate-500" />
                    允许上传
                  </div>
                  <div className="text-xs text-slate-500">允许用户上传文件</div>
                </div>
                <Switch
                  checked={canUpload}
                  onCheckedChange={(checked) => setValue('canUpload', checked)}
                />
              </div>
              <div className="flex items-center justify-between py-2 border-b border-slate-100">
                <div>
                  <div className="text-sm font-medium text-slate-800 flex items-center gap-2">
                    <Share2 className="w-4 h-4 text-slate-500" />
                    允许分享
                  </div>
                  <div className="text-xs text-slate-500">允许用户创建分享链接</div>
                </div>
                <Switch
                  checked={canShare}
                  onCheckedChange={(checked) => setValue('canShare', checked)}
                />
              </div>
              <div className="flex items-center justify-between py-2">
                <div>
                  <div className="text-sm font-medium text-slate-800 flex items-center gap-2">
                    <Key className="w-4 h-4 text-slate-500" />
                    允许使用 API
                  </div>
                  <div className="text-xs text-slate-500">允许用户创建 API Key</div>
                </div>
                <Switch
                  checked={canUseApi}
                  onCheckedChange={(checked) => setValue('canUseApi', checked)}
                />
              </div>
            </div>
          </div>

          <Field>
            <FieldLabel>
              允许的文件类型
              <span className="text-slate-400 font-normal">（留空表示不限制）</span>
            </FieldLabel>
            <FieldContent>
              <Input
                type="text"
                placeholder="例如：jpg, png, pdf, docx"
                {...register('allowedFileTypes')}
              />
              <p className="text-xs text-slate-400 mt-1">
                用逗号分隔多个扩展名，留空表示允许所有类型
              </p>
            </FieldContent>
          </Field>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              取消
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {isEdit ? '保存' : '创建'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
