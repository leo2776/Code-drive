import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import {
  Plus,
  Trash2,
  Copy,
  Key,
  ChevronLeft,
  ChevronRight,
  Loader2,
  CheckCircle,
  Ban,
  Calendar,
} from 'lucide-react';
import dayjs from 'dayjs';

import { apiKeys as apiKeysApi } from '@client/src/api';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import { Badge } from '@client/src/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@client/src/components/ui/alert-dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import { Calendar as CalendarComponent } from '@client/src/components/ui/calendar';
import {
  Field,
  FieldLabel,
  FieldContent,
  FieldError,
} from '@client/src/components/ui/field';
import { formatFileSize, formatDateTime } from '@client/src/utils/format';
import { getApiErrorMessage } from '@client/src/lib/api-error';
import { API_PERMISSION_LABELS } from '@shared/api.interface';
import type { ApiKeyInfo, ApiPermission } from '@shared/api.interface';

const PAGE_SIZE = 10;

const apiKeyCreateSchema = z.object({
  name: z.string().min(1, { message: '请输入名称' }),
  permission: z.enum(['read', 'readwrite']),
  hasQuota: z.boolean(),
  quotaValue: z.number().optional(),
  quotaUnit: z.enum(['MB', 'GB']),
  hasExpiry: z.boolean(),
  expiresAt: z.date().optional(),
});

export default function ApiKeysPage() {
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newKey, setNewKey] = useState<{ apiKey: ApiKeyInfo; key: string } | null>(null);
  const [copied, setCopied] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<ApiKeyInfo | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['api-keys', { page, pageSize: PAGE_SIZE }],
    queryFn: () => apiKeysApi.list(page, PAGE_SIZE),
  });

  const createMutation = useMutation({
    mutationFn: (formData: z.infer<typeof apiKeyCreateSchema>) => {
      let quotaBytes: number | null = null;
      if (formData.hasQuota && formData.quotaValue && formData.quotaValue > 0) {
        quotaBytes =
          formData.quotaUnit === 'GB'
            ? formData.quotaValue * 1024 * 1024 * 1024
            : formData.quotaValue * 1024 * 1024;
      }
      let expiresAt: string | null = null;
      if (formData.hasExpiry && formData.expiresAt) {
        expiresAt = formData.expiresAt.toISOString();
      }
      return apiKeysApi.create({
        name: formData.name,
        permission: formData.permission,
        quotaBytes,
        expiresAt,
      });
    },
    onSuccess: (result: { apiKey: ApiKeyInfo; key: string }) => {
      toast.success('API Key 创建成功');
      setDialogOpen(false);
      setNewKey(result);
      queryClient.invalidateQueries({ queryKey: ['api-keys'] });
    },
    onError: (error) => {
      toast.error(getApiErrorMessage(error, '创建 API Key 失败'));
    },
  });

  const toggleMutation = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) =>
      apiKeysApi.toggleActive(id, isActive),
    onSuccess: () => {
      toast.success('状态已更新');
      queryClient.invalidateQueries({ queryKey: ['api-keys'] });
    },
    onError: (error) => {
      toast.error(getApiErrorMessage(error, '操作失败'));
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiKeysApi.remove(id),
    onSuccess: () => {
      toast.success('API Key 已删除');
      setDeleteTarget(null);
      queryClient.invalidateQueries({ queryKey: ['api-keys'] });
    },
    onError: (error) => {
      toast.error(getApiErrorMessage(error, '删除失败'));
    },
  });

  const handleCopyKey = async (key: string) => {
    try {
      await navigator.clipboard.writeText(key);
      setCopied(true);
      toast.success('已复制到剪贴板');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('复制失败，请手动复制');
    }
  };

  const items: ApiKeyInfo[] = data?.items ?? [];
  const total: number = data?.total ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold mb-6">API Key 管理</h1>

      {/* 工具栏 */}
      <div className="flex items-center justify-between mb-4">
        <div className="text-sm text-slate-500">
          管理 API 访问密钥，用于程序化访问云盘资源
        </div>
        <Button onClick={() => setDialogOpen(true)}>
          <Plus className="w-4 h-4" />
          新增 API Key
        </Button>
      </div>

      {/* 新建成功提示 */}
      {newKey && (
        <div className="mb-6 p-4 bg-emerald-50 border border-emerald-200 rounded-lg">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="font-medium text-emerald-800 mb-1">
                API Key 创建成功！请立即保存，关闭后无法再次查看
              </div>
              <div className="flex items-center gap-2 bg-white rounded-md border border-emerald-200 px-3 py-2">
                <Key className="w-4 h-4 text-slate-400 flex-shrink-0" />
                <code className="flex-1 text-sm font-mono text-slate-700 truncate">
                  {newKey.key}
                </code>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleCopyKey(newKey.key)}
                  aria-label="复制 API Key"
                >
                  {copied ? (
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </Button>
              </div>
              <div className="text-xs text-emerald-600 mt-2">
                名称：{newKey.apiKey.name} · 权限：{API_PERMISSION_LABELS[newKey.apiKey.permission as ApiPermission]}
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setNewKey(null)}
              aria-label="关闭提示"
            >
              关闭
            </Button>
          </div>
        </div>
      )}

      {/* 表格 */}
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>名称</TableHead>
              <TableHead>前缀</TableHead>
              <TableHead>权限</TableHead>
              <TableHead>配额</TableHead>
              <TableHead>调用次数</TableHead>
              <TableHead>过期时间</TableHead>
              <TableHead>状态</TableHead>
              <TableHead className="text-right">操作</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-slate-500">
                  <Loader2 className="w-5 h-5 animate-spin mx-auto" />
                </TableCell>
              </TableRow>
            ) : items.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-slate-500">
                  暂无 API Key
                </TableCell>
              </TableRow>
            ) : (
              items.map((apiKey) => {
                const isExpired = apiKey.expiresAt
                  ? dayjs(apiKey.expiresAt).isBefore(dayjs())
                  : false;
                return (
                  <TableRow key={apiKey.id}>
                    <TableCell className="font-medium text-slate-800">
                      {apiKey.name}
                    </TableCell>
                    <TableCell>
                      <code className="text-sm text-slate-600 font-mono bg-slate-100 px-2 py-0.5 rounded">
                        {apiKey.keyPrefix}***
                      </code>
                    </TableCell>
                    <TableCell>
                      <Badge variant={apiKey.permission === 'readwrite' ? 'default' : 'secondary'}>
                        {API_PERMISSION_LABELS[apiKey.permission as ApiPermission]}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-slate-600">
                      {apiKey.quotaBytes
                        ? `${formatFileSize(apiKey.usedBytes)} / ${formatFileSize(apiKey.quotaBytes)}`
                        : '不限制'}
                    </TableCell>
                    <TableCell className="text-sm text-slate-600">
                      {apiKey.callCount.toLocaleString()}
                    </TableCell>
                    <TableCell className="text-sm">
                      {apiKey.expiresAt ? (
                        <span className={isExpired ? 'text-destructive' : 'text-slate-600'}>
                          {formatDateTime(apiKey.expiresAt)}
                          {isExpired && '（已过期）'}
                        </span>
                      ) : (
                        <span className="text-slate-400">永不过期</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={apiKey.isActive && !isExpired ? 'default' : 'secondary'}
                        className={
                          apiKey.isActive && !isExpired
                            ? 'bg-emerald-500 border-emerald-500'
                            : 'bg-slate-200 text-slate-600 border-slate-200'
                        }
                      >
                        {apiKey.isActive && !isExpired ? '启用' : '禁用'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() =>
                            toggleMutation.mutate({
                              id: apiKey.id,
                              isActive: !apiKey.isActive,
                            })
                          }
                          aria-label={apiKey.isActive ? `禁用 ${apiKey.name}` : `启用 ${apiKey.name}`}
                        >
                          {apiKey.isActive ? (
                            <Ban className="w-4 h-4 text-amber-600" />
                          ) : (
                            <CheckCircle className="w-4 h-4 text-emerald-600" />
                          )}
                        </Button>
                        <AlertDialog
                          open={deleteTarget?.id === apiKey.id}
                          onOpenChange={(open) => {
                            if (!open) setDeleteTarget(null);
                          }}
                        >
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => setDeleteTarget(apiKey)}
                              aria-label={`删除 ${apiKey.name}`}
                            >
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>确认删除 API Key</AlertDialogTitle>
                              <AlertDialogDescription>
                                确定要删除 API Key「{deleteTarget?.name}」吗？
                                删除后该密钥将立即失效，无法恢复。
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>取消</AlertDialogCancel>
                              <AlertDialogAction
                                className="bg-destructive hover:bg-destructive/90"
                                onClick={() => {
                                  if (deleteTarget) {
                                    deleteMutation.mutate(deleteTarget.id);
                                  }
                                }}
                              >
                                {deleteMutation.isPending && (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                )}
                                确认删除
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* 分页 */}
      <div className="flex items-center justify-between mt-4">
        <div className="text-sm text-slate-500">
          共 {total} 条，第 {page} / {totalPages} 页
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page <= 1}
          >
            <ChevronLeft className="w-4 h-4" />
            上一页
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
          >
            下一页
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* 新建对话框 */}
      <CreateApiKeyDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onSubmit={(data) => createMutation.mutate(data)}
        isSubmitting={createMutation.isPending}
      />
    </div>
  );
}

interface CreateApiKeyDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: z.infer<typeof apiKeyCreateSchema>) => void;
  isSubmitting: boolean;
}

function CreateApiKeyDialog({
  open,
  onOpenChange,
  onSubmit,
  isSubmitting,
}: CreateApiKeyDialogProps) {
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<z.infer<typeof apiKeyCreateSchema>>({
    resolver: zodResolver(apiKeyCreateSchema),
    defaultValues: {
      name: '',
      permission: 'read',
      hasQuota: false,
      quotaValue: 1,
      quotaUnit: 'GB',
      hasExpiry: false,
      expiresAt: undefined,
    },
  });

  // 打开时重置表单
  useEffect(() => {
    if (open) {
      reset({
        name: '',
        permission: 'read',
        hasQuota: false,
        quotaValue: 1,
        quotaUnit: 'GB',
        hasExpiry: false,
        expiresAt: undefined,
      });
    }
  }, [open, reset]);

  const hasQuota = watch('hasQuota');
  const hasExpiry = watch('hasExpiry');
  const permission = watch('permission');
  const quotaUnit = watch('quotaUnit');
  const expiresAt = watch('expiresAt');

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>新建 API Key</DialogTitle>
          <DialogDescription>
            创建一个新的 API 访问密钥，用于程序化访问云盘资源
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <Field>
            <FieldLabel>名称</FieldLabel>
            <FieldContent>
              <Input
                type="text"
                placeholder="请输入 API Key 名称"
                {...register('name')}
                aria-invalid={!!errors.name}
              />
              <FieldError errors={[errors.name]} />
            </FieldContent>
          </Field>

          <Field>
            <FieldLabel>权限</FieldLabel>
            <FieldContent>
              <Select
                value={permission}
                onValueChange={(val) =>
                  setValue('permission', val as ApiPermission)
                }
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="选择权限" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="read">只读（读取文件、下载）</SelectItem>
                  <SelectItem value="readwrite">读写（上传、删除、管理）</SelectItem>
                </SelectContent>
              </Select>
            </FieldContent>
          </Field>

          {/* 配额 */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-slate-800">存储配额</div>
                <div className="text-xs text-slate-500">设置该 API Key 的存储上限</div>
              </div>
              <input
                type="checkbox"
                id="hasQuota"
                checked={hasQuota}
                onChange={(e) => setValue('hasQuota', e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
              />
            </div>
            {hasQuota && (
              <div className="pl-0">
                <div className="flex gap-2">
                  <Input
                    type="number"
                    min={1}
                    placeholder="配额大小"
                    {...register('quotaValue', { valueAsNumber: true })}
                    aria-invalid={!!errors.quotaValue}
                  />
                  <Select
                    value={quotaUnit}
                    onValueChange={(val) =>
                      setValue('quotaUnit', val as 'MB' | 'GB')
                    }
                  >
                    <SelectTrigger className="w-24 flex-shrink-0">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MB">MB</SelectItem>
                      <SelectItem value="GB">GB</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
          </div>

          {/* 过期时间 */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-slate-800">过期时间</div>
                <div className="text-xs text-slate-500">设置后过期自动失效</div>
              </div>
              <input
                type="checkbox"
                id="hasExpiry"
                checked={hasExpiry}
                onChange={(e) => setValue('hasExpiry', e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
              />
            </div>
            {hasExpiry && (
              <div className="pl-0">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      type="button"
                      className="w-full justify-start text-left font-normal"
                    >
                      <Calendar className="w-4 h-4 mr-2" />
                      {expiresAt
                        ? dayjs(expiresAt).format('YYYY-MM-DD')
                        : '选择过期日期'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <CalendarComponent
                      mode="single"
                      selected={expiresAt}
                      onSelect={(date) => {
                        if (date) {
                          setValue('expiresAt', date);
                        }
                      }}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              取消
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
              创建
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
