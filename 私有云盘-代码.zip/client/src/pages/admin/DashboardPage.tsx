import { useQuery } from '@tanstack/react-query';
import {
  HardDrive,
  Users,
  FileText,
  Activity,
  Upload,
  Share2,
  TrendingUp,
} from 'lucide-react';

import { dashboard as dashboardApi } from '@client/src/api';
import { Card, CardContent, CardHeader, CardTitle } from '@client/src/components/ui/card';
import { Badge } from '@client/src/components/ui/badge';
import { formatFileSize, formatDateTime } from '@client/src/utils/format';
import { getApiErrorMessage } from '@client/src/lib/api-error';
import { StorageBar, getStorageLevel } from '@client/src/components/ui/storage-bar';
import type { DashboardStats } from '@shared/api.interface';

const SYSTEM_TOTAL_BYTES = 10 * 1024 * 1024 * 1024 * 1024; // 10 TB 系统总容量

const statCards = [
  { key: 'totalStorageBytes', label: '已用存储', icon: HardDrive, color: 'text-blue-600 bg-blue-50' },
  { key: 'totalQuotaBytes', label: '总配额', icon: HardDrive, color: 'text-indigo-600 bg-indigo-50' },
  { key: 'totalUsers', label: '用户数', icon: Users, color: 'text-emerald-600 bg-emerald-50' },
  { key: 'totalFiles', label: '文件总数', icon: FileText, color: 'text-amber-600 bg-amber-50' },
  { key: 'totalApiCalls', label: 'API 调用次数', icon: Activity, color: 'text-purple-600 bg-purple-50' },
] as const;

function formatStatValue(key: string, value: number): string {
  if (key === 'totalStorageBytes') return formatFileSize(value);
  return value.toLocaleString();
}

export default function DashboardPage() {
  const { data, isLoading, error } = useQuery<DashboardStats>({
    queryKey: ['dashboard-stats'],
    queryFn: () => dashboardApi.getStats(),
  });

  if (isLoading) {
    return (
      <div className="p-6">
        <h1 className="text-xl font-semibold mb-6">仪表盘</h1>
        <div className="text-muted-foreground">加载中...</div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="p-6">
        <h1 className="text-xl font-semibold mb-6">仪表盘</h1>
        <div className="text-destructive">
          {getApiErrorMessage(error, '加载仪表盘数据失败')}
        </div>
      </div>
    );
  }

  const maxStorage = Math.max(
    ...data.storageByUser.map((item) => item.usedBytes),
    1
  );

  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold mb-6">仪表盘</h1>

      {/* 统计卡片 */}
      <div
        data-ai-section-type="card-stat"
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6"
      >
        {statCards.map((card) => (
          <Card key={card.key}>
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-slate-900">
                    {formatStatValue(card.key, data[card.key])}
                  </div>
                  <div className="text-sm text-slate-500 mt-1">
                    {card.label}
                  </div>
                </div>
                <div className={`p-3 rounded-lg ${card.color}`}>
                  <card.icon className="w-6 h-6" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 全局容量总览 */}
      <Card className="mb-6">
        <CardHeader className="p-5 pb-3">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-blue-600" />
            系统存储容量
          </CardTitle>
        </CardHeader>
        <CardContent className="p-5 pt-0">
          <div className="grid grid-cols-3 gap-6 mb-4">
            <div>
              <div className="text-xs text-slate-500 mb-1">已用存储</div>
              <div className="text-xl font-bold text-slate-800">
                {formatFileSize(data.totalStorageBytes)}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500 mb-1">系统总容量</div>
              <div className="text-xl font-bold text-slate-800">
                {formatFileSize(SYSTEM_TOTAL_BYTES)}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500 mb-1">剩余可用</div>
              <div className="text-xl font-bold text-emerald-600">
                {formatFileSize(Math.max(0, SYSTEM_TOTAL_BYTES - data.totalStorageBytes))}
              </div>
            </div>
          </div>
          <StorageBar
            usedBytes={data.totalStorageBytes}
            quotaBytes={SYSTEM_TOTAL_BYTES}
            size="md"
            showLabel={false}
            showRemaining={false}
          />
          <div className="text-xs text-slate-500 mt-1.5 text-right">
            使用率 {((data.totalStorageBytes / SYSTEM_TOTAL_BYTES) * 100).toFixed(2)}%
          </div>
        </CardContent>
      </Card>

      {/* 最近上传 & 最近分享 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <Card>
          <CardHeader className="p-5 pb-3">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Upload className="w-4 h-4 text-blue-600" />
              最近上传
            </CardTitle>
          </CardHeader>
          <CardContent className="p-5 pt-0">
            {data.recentUploads.length === 0 ? (
              <div className="text-sm text-slate-500 text-center py-6">
                暂无上传记录
              </div>
            ) : (
              <div className="space-y-3">
                {data.recentUploads.map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between py-2 border-b border-slate-100 last:border-b-0"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-9 rounded-md bg-blue-50 flex items-center justify-center flex-shrink-0">
                        <FileText className="w-4 h-4 text-blue-600" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-slate-800 truncate">
                          {file.name}
                        </div>
                        <div className="text-xs text-slate-500">
                          {formatFileSize(file.sizeBytes)}
                        </div>
                      </div>
                    </div>
                    <div className="text-xs text-slate-400 flex-shrink-0 ml-2">
                      {formatDateTime(file.createdAt)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="p-5 pb-3">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Share2 className="w-4 h-4 text-emerald-600" />
              最近分享
            </CardTitle>
          </CardHeader>
          <CardContent className="p-5 pt-0">
            {data.recentShares.length === 0 ? (
              <div className="text-sm text-slate-500 text-center py-6">
                暂无分享记录
              </div>
            ) : (
              <div className="space-y-3">
                {data.recentShares.map((share) => (
                  <div
                    key={share.id}
                    className="flex items-center justify-between py-2 border-b border-slate-100 last:border-b-0"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-9 rounded-md bg-emerald-50 flex items-center justify-center flex-shrink-0">
                        <Share2 className="w-4 h-4 text-emerald-600" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-slate-800 truncate">
                          {share.fileName}
                        </div>
                        <div className="text-xs text-slate-500">
                          {share.viewCount} 次浏览
                        </div>
                      </div>
                    </div>
                    <div className="text-xs text-slate-400 flex-shrink-0 ml-2">
                      {formatDateTime(share.createdAt)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* 存储使用排行 */}
      <Card>
        <CardHeader className="p-5 pb-3">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-amber-600" />
            存储使用排行（TOP 10）
          </CardTitle>
        </CardHeader>
        <CardContent className="p-5 pt-0">
          {data.storageByUser.length === 0 ? (
            <div className="text-sm text-slate-500 text-center py-6">
              暂无数据
            </div>
          ) : (
            <div className="space-y-4">
              {data.storageByUser.map((item, index) => {
                const isAdmin = item.role === 'admin';
                const percent = isAdmin || item.quotaBytes <= 0
                  ? 0
                  : Math.min(100, (item.usedBytes / item.quotaBytes) * 100);
                const level = getStorageLevel(item.usedBytes, item.quotaBytes);
                const barColor = isAdmin
                  ? 'bg-slate-300'
                  : level === 'normal'
                    ? 'bg-blue-500'
                    : level === 'warning'
                      ? 'bg-amber-500'
                      : 'bg-red-500';
                const remaining = Math.max(0, item.quotaBytes - item.usedBytes);
                return (
                  <div key={item.username}>
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <Badge
                          variant={index < 3 ? 'default' : 'secondary'}
                          className={
                            index < 3
                              ? index === 0
                                ? 'bg-amber-500 border-amber-500'
                                : index === 1
                                  ? 'bg-slate-400 border-slate-400'
                                  : 'bg-orange-400 border-orange-400'
                              : ''
                          }
                        >
                          {index + 1}
                        </Badge>
                        <span className="text-sm font-medium text-slate-800">
                          {item.username}
                        </span>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium text-slate-700">
                          {formatFileSize(item.usedBytes)}
                          <span className="text-slate-400 font-normal"> / {isAdmin ? '无限制' : formatFileSize(item.quotaBytes)}</span>
                        </div>
                        <div className="text-xs text-slate-400">
                          {isAdmin ? '容量无限制' : `剩余 ${formatFileSize(remaining)} · ${percent.toFixed(1)}%`}
                        </div>
                      </div>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${barColor} rounded-full transition-all`}
                        style={{ width: isAdmin ? '100%' : `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
