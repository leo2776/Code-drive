import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  File,
  Folder,
  Lock,
  Download,
  Eye,
  EyeOff,
  AlertTriangle,
  HardDrive,
  Clock,
  ArrowLeft,
} from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@client/src/components/ui/card';
import { formatFileSize, formatDateTime, isImageFile } from '@client/src/utils/format';
import { useSharePublicInfo, useAccessShare } from '@client/src/hooks/useShares';
import { resolveAppUrl } from '@lark-apaas/client-toolkit/utils/resolveAppUrl';
import type { FileItem, ShareInfo } from '@shared/api.interface';
import { Image } from '@client/src/components/ui/image';

export default function ShareViewPage() {
  const { token = '' } = useParams<{ token: string }>();
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [accessGranted, setAccessGranted] = useState(false);
  // Path stack: list of folders we've navigated into (for "back" functionality)
  // Each entry is the id and name of the folder we were in before navigating deeper
  const [pathStack, setPathStack] = useState<{ id: string; name: string }[]>([]);

  const {
    data: publicInfo,
    isLoading: infoLoading,
    error: infoError,
  } = useSharePublicInfo(token);

  const accessMutation = useAccessShare(token);

  // Auto-access if no password needed
  useEffect(() => {
    if (publicInfo && !publicInfo.needPassword && !accessGranted && !accessMutation.data) {
      accessMutation.mutate(
        { password: undefined },
        {
          onSuccess: () => setAccessGranted(true),
        },
      );
    }
  }, [publicInfo, accessGranted, accessMutation]);

  const handleSubmitPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) {
      toast.error('请输入提取码');
      return;
    }
    accessMutation.mutate(
      { password },
      {
        onSuccess: () => setAccessGranted(true),
      },
    );
  };

  const handleEnterFolder = (folder: FileItem) => {
    const currentFile = accessMutation.data?.file;
    if (!currentFile) return;
    setPathStack((prev) => [...prev, { id: currentFile.id, name: currentFile.name }]);
    accessMutation.mutate({ password: password || undefined, folderId: folder.id });
  };

  const handleGoBack = () => {
    if (pathStack.length === 0) return;
    const newStack = [...pathStack];
    const parent = newStack.pop();
    setPathStack(newStack);
    accessMutation.mutate({ password: password || undefined, folderId: parent?.id });
  };

  const share = publicInfo?.share as Omit<ShareInfo, 'token'> | undefined;
  const accessedShare = accessMutation.data?.share;
  const accessedFile = accessMutation.data?.file;
  const children = accessMutation.data?.children;
  const downloadUrl = accessMutation.data?.downloadUrl;

  const handleDownload = () => {
    if (!downloadUrl) {
      toast.error('下载链接不可用');
      return;
    }
    const a = document.createElement('a');
    a.href = downloadUrl;
    a.download = accessedFile?.name ?? 'download';
    a.click();
  };

  // Error / invalid state
  if (infoError) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="flex flex-col items-center py-12">
            <div className="w-16 h-16 rounded-full bg-red-50 flex items-center justify-center mb-4">
              <AlertTriangle className="w-8 h-8 text-red-500" />
            </div>
            <h2 className="text-lg font-semibold text-slate-800 mb-2">
              分享链接无效或已过期
            </h2>
            <p className="text-sm text-slate-500 text-center">
              该分享链接不存在、已被撤销或已过期。
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Loading state
  if (infoLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-500">加载中...</div>
      </div>
    );
  }

  // Password required, not yet accessed
  if (publicInfo?.needPassword && !accessGranted) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center pb-2">
            <div className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-blue-600" />
            </div>
            <CardTitle className="text-lg">访问加密分享</CardTitle>
            <p className="text-sm text-slate-500 mt-1">
              该分享需要提取码，请输入后访问
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmitPassword} className="space-y-4">
              <div className="relative">
                <Input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="请输入提取码"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                  aria-label={showPassword ? '隐藏密码' : '显示密码'}
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
              <Button
                type="submit"
                className="w-full"
                disabled={accessMutation.isPending}
              >
                {accessMutation.isPending ? '验证中...' : '提取文件'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Access granted / no password needed - show content
  const activeShare = accessedShare ?? share;
  const activeFile = accessedFile ?? publicInfo?.file;

  if (!activeFile) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-500">加载中...</div>
      </div>
    );
  }

  const isFolder = activeFile.type === 'folder';

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center gap-3">
          <HardDrive className="w-5 h-5 text-blue-600" />
          <span className="font-semibold text-slate-800">云盘分享</span>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-4xl mx-auto px-4 py-6">
        <Card className="w-full">
          <CardHeader className="pb-4">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
                {isFolder ? (
                  <Folder className="w-6 h-6 text-amber-500" />
                ) : (
                  <File className="w-6 h-6 text-blue-500" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <CardTitle className="text-lg truncate" title={activeFile.name}>
                  {activeFile.name}
                </CardTitle>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1 text-xs text-slate-500">
                  <span>{isFolder ? '文件夹' : formatFileSize(activeFile.sizeBytes)}</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {activeShare?.expiresAt
                      ? `有效期至 ${formatDateTime(activeShare.expiresAt)}`
                      : '永久有效'}
                  </span>
                  {activeShare?.viewCount !== undefined && (
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      {activeShare.viewCount} 次浏览
                    </span>
                  )}
                </div>
              </div>
            </div>
          </CardHeader>

          <CardContent>
            {/* File view */}
            {!isFolder && (
              <div className="space-y-4">
                {/* Image preview */}
                {isImageFile(activeFile.mimeType) && downloadUrl && (
                  <div className="flex justify-center bg-slate-50 rounded-lg p-4">
                    <Image
                      src={downloadUrl}
                      alt={activeFile.name}
                      className="max-w-full max-h-[500px] object-contain rounded"
                    />
                  </div>
                )}

                {/* Non-image placeholder */}
                {!isImageFile(activeFile.mimeType) && (
                  <div className="flex flex-col items-center justify-center bg-slate-50 rounded-lg py-12">
                    <File className="w-16 h-16 text-slate-300 mb-3" />
                    <p className="text-sm text-slate-500">
                      该文件类型暂不支持在线预览
                    </p>
                  </div>
                )}

                {/* Download button */}
                {activeShare?.allowDownload !== false && (
                  <Button
                    className="w-full bg-green-600 hover:bg-green-700 border-green-700"
                    onClick={handleDownload}
                  >
                    <Download className="w-4 h-4" />
                    下载文件
                  </Button>
                )}

                {activeShare?.allowDownload === false && (
                  <p className="text-center text-xs text-slate-400">
                    分享者未开放下载权限
                  </p>
                )}
              </div>
            )}

            {/* Folder view */}
            {isFolder && (
              <div className="space-y-4">
                {/* Back button */}
                {pathStack.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleGoBack}
                    className="-ml-2 text-slate-600"
                  >
                    <ArrowLeft className="w-4 h-4 mr-1" />
                    返回上级
                  </Button>
                )}

                {/* File list */}
                {children && children.length > 0 ? (
                  <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden">
                    {children.map((item: FileItem) => (
                      <div
                        key={item.id}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-slate-50 transition-colors"
                      >
                        {item.type === 'folder' ? (
                          <button
                            onClick={() => handleEnterFolder(item)}
                            className="flex items-center gap-3 flex-1 text-left"
                          >
                            <Folder className="w-5 h-5 text-amber-500 flex-shrink-0" />
                            <span className="text-sm text-slate-700 truncate">
                              {item.name}
                            </span>
                          </button>
                        ) : (
                          <>
                            <File className="w-5 h-5 text-blue-500 flex-shrink-0" />
                            <span className="text-sm text-slate-700 flex-1 truncate">
                              {item.name}
                            </span>
                            <span className="text-xs text-slate-400 flex-shrink-0">
                              {formatFileSize(item.sizeBytes)}
                            </span>
                            {activeShare?.allowDownload !== false && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  toast.info('请通过文件详情页下载');
                                }}
                                aria-label="下载"
                                className="text-slate-400 hover:text-blue-600"
                              >
                                <Download className="w-4 h-4" />
                              </Button>
                            )}
                          </>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-slate-400">
                    <Folder className="w-10 h-10 mb-2 opacity-50" />
                    <p className="text-sm">文件夹为空</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Footer info */}
        <div className="text-center text-xs text-slate-400 mt-6">
          分享来自云盘 · {resolveAppUrl('/')}
        </div>
      </main>
    </div>
  );
}
