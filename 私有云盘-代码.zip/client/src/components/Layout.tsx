import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  HardDrive,
  Share2,
  LayoutDashboard,
  Users,
  Key,
  LogOut,
  Menu,
  X,
} from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '@client/src/contexts/auth-context';
import { Button } from '@client/src/components/ui/button';
import { cn } from '@client/src/utils/cn';

export default function AppLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { path: '/files', label: '我的文件', icon: HardDrive },
    { path: '/shares', label: '我的分享', icon: Share2 },
  ];

  const adminItems = [
    { path: '/admin/dashboard', label: '仪表盘', icon: LayoutDashboard },
    { path: '/admin/users', label: '用户管理', icon: Users },
    { path: '/admin/api', label: 'API 管理', icon: Key },
  ];

  return (
    <div className="flex h-screen bg-slate-50">
      {/* 移动端遮罩 */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* 侧边栏 */}
      <aside
        className={cn(
          'fixed lg:static inset-y-0 left-0 z-50 w-60 bg-white border-r border-slate-200 flex flex-col transition-transform duration-300',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
        )}
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-5 border-b border-slate-200">
          <HardDrive className="w-6 h-6 text-blue-600 mr-2" />
          <span className="font-semibold text-lg text-slate-800">云盘</span>
        </div>

        {/* 导航 */}
        <nav className="flex-1 py-4 overflow-y-auto">
          <div className="px-3 space-y-1">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setSidebarOpen(false)}
                className={({ isActive }) =>
                  cn(
                    'flex items-center px-3 py-2 text-sm rounded-md transition-colors',
                    isActive
                      ? 'bg-blue-50 text-blue-700 font-medium'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900',
                  )
                }
              >
                <item.icon className="w-5 h-5 mr-3" />
                {item.label}
              </NavLink>
            ))}
          </div>

          {user?.role === 'admin' && (
            <div className="mt-6">
              <div className="px-5 mb-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                管理后台
              </div>
              <div className="px-3 space-y-1">
                {adminItems.map((item) => (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    onClick={() => setSidebarOpen(false)}
                    className={({ isActive }) =>
                      cn(
                        'flex items-center px-3 py-2 text-sm rounded-md transition-colors',
                        isActive
                          ? 'bg-blue-50 text-blue-700 font-medium'
                          : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900',
                      )
                    }
                  >
                    <item.icon className="w-5 h-5 mr-3" />
                    {item.label}
                  </NavLink>
                ))}
              </div>
            </div>
          )}
        </nav>

        {/* 用户信息 */}
        <div className="p-4 border-t border-slate-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center min-w-0">
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-medium text-sm flex-shrink-0">
                {user?.username?.[0]?.toUpperCase()}
              </div>
              <div className="ml-3 min-w-0">
                <div className="text-sm font-medium text-slate-800 truncate">
                  {user?.username}
                </div>
                <div className="text-xs text-slate-500">
                  {user?.role === 'admin' ? '管理员' : '普通用户'}
                </div>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              aria-label="退出登录"
            >
              <LogOut className="w-4 h-4 text-slate-500" />
            </Button>
          </div>
        </div>
      </aside>

      {/* 主内容区 */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* 顶部栏 - 移动端显示菜单按钮 */}
        <header className="h-14 bg-white border-b border-slate-200 flex items-center px-4 lg:hidden">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(true)}
            aria-label="打开菜单"
          >
            <Menu className="w-5 h-5" />
          </Button>
          {sidebarOpen && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(false)}
              aria-label="关闭菜单"
              className="ml-auto"
            >
              <X className="w-5 h-5" />
            </Button>
          )}
        </header>

        {/* 页面内容 */}
        <main className="flex-1 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
