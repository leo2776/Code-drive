import { HardDrive, Infinity as InfinityIcon } from 'lucide-react';
import { formatFileSize } from '@client/src/utils/format';

interface StorageBarProps {
  usedBytes: number;
  quotaBytes: number;
  size?: 'sm' | 'md';
  showLabel?: boolean;
  showRemaining?: boolean;
  unlimited?: boolean;
}

export function getStorageLevel(usedBytes: number, quotaBytes: number): 'normal' | 'warning' | 'danger' {
  if (quotaBytes <= 0) return 'normal';
  const percent = (usedBytes / quotaBytes) * 100;
  if (percent >= 95) return 'danger';
  if (percent >= 80) return 'warning';
  return 'normal';
}

const levelColors = {
  normal: 'bg-emerald-500',
  warning: 'bg-amber-500',
  danger: 'bg-red-500',
} as const;

const levelTextColors = {
  normal: 'text-emerald-600',
  warning: 'text-amber-600',
  danger: 'text-red-600',
} as const;

export function StorageBar({
  usedBytes,
  quotaBytes,
  size = 'md',
  showLabel = true,
  showRemaining = true,
  unlimited = false,
}: StorageBarProps) {
  const percent = unlimited || quotaBytes <= 0 ? 0 : Math.min(100, (usedBytes / quotaBytes) * 100);
  const remainingBytes = unlimited ? Infinity : Math.max(0, quotaBytes - usedBytes);
  const level = unlimited ? 'normal' : getStorageLevel(usedBytes, quotaBytes);

  const barHeight = size === 'sm' ? 'h-1.5' : 'h-2.5';
  const textSize = size === 'sm' ? 'text-xs' : 'text-sm';

  return (
    <div className="w-full">
      {showLabel && (
        <div className={`flex items-center justify-between mb-1.5 ${textSize}`}>
          <div className="flex items-center gap-1.5 text-slate-500">
            <HardDrive className="w-3.5 h-3.5" />
            <span>
              已用 <span className="font-medium text-slate-700">{formatFileSize(usedBytes)}</span>
              {' / '}
              {unlimited ? (
                <span className="inline-flex items-center gap-0.5 text-slate-600">
                  <InfinityIcon className="w-3 h-3" />
                  无限制
                </span>
              ) : (
                formatFileSize(quotaBytes)
              )}
            </span>
          </div>
          {!unlimited && (
            <span className={`font-medium ${levelTextColors[level]}`}>
              {percent.toFixed(1)}%
            </span>
          )}
        </div>
      )}
      {unlimited ? (
        <div className={`w-full ${barHeight} bg-slate-100 rounded-full overflow-hidden`}>
          <div
            className="h-full bg-slate-400/40 rounded-full"
            style={{ width: '100%' }}
          />
        </div>
      ) : (
        <div className={`w-full ${barHeight} bg-slate-100 rounded-full overflow-hidden`}>
          <div
            className={`h-full ${levelColors[level]} rounded-full transition-all duration-500`}
            style={{ width: `${percent}%` }}
          />
        </div>
      )}
      {showRemaining && (
        <div className={`mt-1.5 ${textSize} text-slate-500`}>
          {unlimited ? (
            <span>容量：无限制</span>
          ) : (
            <>剩余可用：<span className="font-medium text-slate-700">{formatFileSize(remainingBytes)}</span></>
          )}
        </div>
      )}
    </div>
  );
}
