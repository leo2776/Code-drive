import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { auth as authApi } from '@client/src/api';
import type { UserInfo } from '@shared/api.interface';

interface AuthContextValue {
  user: UserInfo | null;
  loading: boolean;
  initialized: boolean | null;
  login: (username: string, password: string) => Promise<void>;
  init: (username: string, password: string) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
  checkInitStatus: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const TOKEN_KEY = 'cloud_drive_token';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [initialized, setInitialized] = useState<boolean | null>(null);

  useEffect(() => {
    checkInit();
  }, []);

  const checkInit = async () => {
    try {
      const status = await authApi.getStatus();
      setInitialized(status.initialized);
    } catch (error) {
      logger.error('获取初始化状态失败', error);
      setInitialized(false);
    }

    const token = localStorage.getItem(TOKEN_KEY);
    if (token) {
      await fetchMe(token);
    } else {
      setLoading(false);
    }
  };

  const fetchMe = async (token: string) => {
    try {
      const userData = await authApi.me();
      setUser(userData);
    } catch (error) {
      logger.error('获取用户信息失败', error);
      localStorage.removeItem(TOKEN_KEY);
      setUser(null);
    } finally {
      setLoading(false);
      if (user) setInitialized(true);
    }
  };

  const login = async (username: string, password: string) => {
    const result = await authApi.login(username, password);
    localStorage.setItem(TOKEN_KEY, result.token);
    setUser(result.user);
  };

  const init = async (username: string, password: string) => {
    const result = await authApi.init(username, password);
    localStorage.setItem(TOKEN_KEY, result.token);
    setUser(result.user);
    setInitialized(true);
  };

  const logout = () => {
    localStorage.removeItem(TOKEN_KEY);
    setUser(null);
  };

  const refreshUser = async () => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (token) {
      const userData = await authApi.me();
      setUser(userData);
    }
  };

  const checkInitStatus = async () => {
    try {
      const status = await authApi.getStatus();
      setInitialized(status.initialized);
    } catch (error) {
      logger.error('获取初始化状态失败', error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, initialized, login, init, logout, refreshUser, checkInitStatus }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
