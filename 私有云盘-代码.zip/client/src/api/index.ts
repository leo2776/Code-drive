import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';

export const auth = {
  async getStatus() {
    const res = await axiosForBackend.get('/api/auth/status');
    return res.data;
  },
  async init(username: string, password: string) {
    const res = await axiosForBackend.post('/api/auth/init', { username, password });
    return res.data;
  },
  async login(username: string, password: string) {
    const res = await axiosForBackend.post('/api/auth/login', { username, password });
    return res.data;
  },
  async me() {
    const res = await axiosForBackend.get('/api/auth/me');
    return res.data;
  },
  async logout() {
    const res = await axiosForBackend.post('/api/auth/logout');
    return res.data;
  },
};

export const files = {
  async list(params: { parentId?: string | null; sortBy?: string; sortOrder?: string; search?: string; type?: string }) {
    const res = await axiosForBackend.get('/api/files', { params });
    return res.data;
  },
  async getById(id: string) {
    const res = await axiosForBackend.get(`/api/files/${id}`);
    return res.data;
  },
  async createFolder(name: string, parentId?: string | null) {
    const res = await axiosForBackend.post('/api/files/folder', { name, parentId });
    return res.data;
  },
  async rename(id: string, name: string) {
    const res = await axiosForBackend.patch(`/api/files/${id}/rename`, { name });
    return res.data;
  },
  async move(id: string, targetParentId: string | null) {
    const res = await axiosForBackend.patch(`/api/files/${id}/move`, { targetParentId });
    return res.data;
  },
  async remove(id: string) {
    const res = await axiosForBackend.delete(`/api/files/${id}`);
    return res.data;
  },
  async uploadComplete(data: { name: string; parentId?: string | null; filePath: string; bucketId: string; sizeBytes: number; mimeType?: string }) {
    const res = await axiosForBackend.post('/api/files/upload-complete', data);
    return res.data;
  },
  async getDownloadUrl(id: string) {
    const res = await axiosForBackend.get(`/api/files/${id}/download-url`);
    return res.data;
  },
};

export const shares = {
  async create(data: { fileId: string; password?: string; expiresAt?: string | null; allowDownload?: boolean }) {
    const res = await axiosForBackend.post('/api/shares', data);
    return res.data;
  },
  async list(page = 1, pageSize = 20) {
    const res = await axiosForBackend.get('/api/shares', { params: { page, pageSize } });
    return res.data;
  },
  async remove(id: string) {
    const res = await axiosForBackend.delete(`/api/shares/${id}`);
    return res.data;
  },
  async getPublicInfo(token: string) {
    const res = await axiosForBackend.get(`/api/shares/public/${token}/info`);
    return res.data;
  },
  async accessShare(token: string, password?: string, parentId?: string) {
    const res = await axiosForBackend.post(`/api/shares/public/${token}/access`, { password, parentId });
    return res.data;
  },
};

export const users = {
  async list(params: { page?: number; pageSize?: number; search?: string }) {
    const res = await axiosForBackend.get('/api/users', { params });
    return res.data;
  },
  async getById(id: string) {
    const res = await axiosForBackend.get(`/api/users/${id}`);
    return res.data;
  },
  async create(data: Record<string, unknown>) {
    const res = await axiosForBackend.post('/api/users', data);
    return res.data;
  },
  async update(id: string, data: Record<string, unknown>) {
    const res = await axiosForBackend.patch(`/api/users/${id}`, data);
    return res.data;
  },
  async remove(id: string) {
    const res = await axiosForBackend.delete(`/api/users/${id}`);
    return res.data;
  },
};

export const apiKeys = {
  async create(data: Record<string, unknown>) {
    const res = await axiosForBackend.post('/api/api-keys', data);
    return res.data;
  },
  async list(page = 1, pageSize = 20) {
    const res = await axiosForBackend.get('/api/api-keys', { params: { page, pageSize } });
    return res.data;
  },
  async remove(id: string) {
    const res = await axiosForBackend.delete(`/api/api-keys/${id}`);
    return res.data;
  },
  async toggleActive(id: string, isActive: boolean) {
    const res = await axiosForBackend.patch(`/api/api-keys/${id}/toggle`, { isActive });
    return res.data;
  },
};

export const dashboard = {
  async getStats() {
    const res = await axiosForBackend.get('/api/dashboard/stats');
    return res.data;
  },
};
