import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { shares } from '@client/src/api/index';
import type {
  ShareListResponse,
  SharePublicInfoResponse,
  ShareAccessResponse,
} from '@shared/api.interface';

const QUERY_KEYS = {
  list: (page: number, pageSize: number) => ['shares', 'list', page, pageSize],
  publicInfo: (token: string) => ['shares', 'publicInfo', token],
};

export function useShareList(page = 1, pageSize = 20) {
  return useQuery<ShareListResponse>({
    queryKey: QUERY_KEYS.list(page, pageSize),
    queryFn: () => shares.list(page, pageSize),
  });
}

export function useRemoveShare() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => shares.remove(id),
    retry: false,
    onSuccess: () => {
      toast.success('分享已撤销');
      void queryClient.invalidateQueries({ queryKey: ['shares', 'list'] });
    },
    onError: (error: { response?: { data?: { error?: { message?: string } } } }) => {
      toast.error(error.response?.data?.error?.message ?? '撤销失败');
    },
  });
}

export function useSharePublicInfo(token: string) {
  return useQuery<SharePublicInfoResponse>({
    queryKey: QUERY_KEYS.publicInfo(token),
    queryFn: () => shares.getPublicInfo(token),
    retry: false,
  });
}

export function useAccessShare(token: string) {
  return useMutation<
    ShareAccessResponse,
    { response?: { data?: { error?: { message?: string } } } },
    { password?: string; folderId?: string }
  >({
    mutationFn: ({ password, folderId }: { password?: string; folderId?: string }) =>
      shares.accessShare(token, password, folderId),
    retry: false,
    onError: (error) => {
      toast.error(error.response?.data?.error?.message ?? '访问失败');
    },
  });
}

// helper: derive share type from file type
export function getShareTypeLabel(shareType: string): string {
  return shareType === 'folder' ? '文件夹' : '文件';
}
