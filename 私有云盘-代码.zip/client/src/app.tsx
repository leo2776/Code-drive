import React from 'react';
import { Route, Routes, Navigate } from 'react-router-dom';

import { AuthProvider, useAuth } from './contexts/auth-context';
import AppLayout from './components/Layout';
import InitPage from './pages/Init/InitPage';
import LoginPage from './pages/Login/LoginPage';
import FilesPage from './pages/Files/FilesPage';
import SharesPage from './pages/Shares/SharesPage';
import UsersPage from './pages/admin/UsersPage';
import ApiKeysPage from './pages/admin/ApiKeysPage';
import DashboardPage from './pages/admin/DashboardPage';
import ShareViewPage from './pages/ShareView/ShareViewPage';
import NotFound from './pages/NotFound/NotFound';

import './utils/api-interceptor';

function RootRedirect() {
  const { user, loading, initialized } = useAuth();

  if (loading || initialized === null) {
    return <div className="flex items-center justify-center h-screen">加载中...</div>;
  }

  if (!initialized) {
    return <Navigate to="/init" replace />;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <Navigate to="/files" replace />;
}

function ProtectedRoute({ children, requireAdmin = false }: { children: React.ReactNode; requireAdmin?: boolean }) {
  const { user, loading } = useAuth();
  
  if (loading) {
    return <div className="flex items-center justify-center h-screen">加载中...</div>;
  }
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  if (requireAdmin && user.role !== 'admin') {
    return <Navigate to="/files" replace />;
  }
  
  return <>{children}</>;
}


const RoutesComponent = () => {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/init" element={<InitPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/share/:token" element={<ShareViewPage />} />
        
        <Route element={<AppLayout />}>
          <Route path="/files" element={
            <ProtectedRoute>
              <FilesPage />
            </ProtectedRoute>
          } />
          <Route path="/shares" element={
            <ProtectedRoute>
              <SharesPage />
            </ProtectedRoute>
          } />
          <Route path="/admin/dashboard" element={
            <ProtectedRoute requireAdmin>
              <DashboardPage />
            </ProtectedRoute>
          } />
          <Route path="/admin/users" element={
            <ProtectedRoute requireAdmin>
              <UsersPage />
            </ProtectedRoute>
          } />
          <Route path="/admin/api" element={
            <ProtectedRoute requireAdmin>
              <ApiKeysPage />
            </ProtectedRoute>
          } />
        </Route>

        <Route index element={<RootRedirect />} />

        <Route path="*" element={<NotFound />} />
      </Routes>
    </AuthProvider>
  );
};

export default RoutesComponent;
