/* eslint-disable */
/** auto generated, do not edit */
import { sql } from 'drizzle-orm';
import { bigint, boolean, foreignKey, index, integer, pgTable, text, uniqueIndex, uuid, varchar, customType } from "drizzle-orm/pg-core"

export const customTimestamptz = customType<{
  data: Date;
  driverData: string;
  config: { precision?: number };
}>({
  dataType(config) {
    const precision = typeof config?.precision !== 'undefined'
      ? ` (${config.precision})`
      : '';
    return `timestamptz${precision}`;
  },
  toDriver(value: Date | string | number) {
    if (value == null) return value as any;
    if (typeof value === 'number') return new Date(value).toISOString();
    if (typeof value === 'string') return value;
    if (value instanceof Date) return value.toISOString();
    throw new Error('Invalid timestamp value');
  },
  fromDriver(value: string | Date): Date {
    if (value instanceof Date) return value;
    return new Date(value);
  },
});

export const userProfile = customType<{
  data: string;
  driverData: string;
}>({
  dataType() {
    return 'user_profile';
  },
  toDriver(value: string) {
    return sql`ROW(${value})::user_profile`;
  },
  fromDriver(value: string) {
    const [userId] = value.slice(1, -1).split(',');
    return userId.trim();
  },
});

export type FileAttachment = {
  bucket_id: string;
  file_path: string;
};

export const fileAttachment = customType<{
  data: FileAttachment;
  driverData: string;
}>({
  dataType() {
    return 'file_attachment';
  },
  toDriver(value: FileAttachment) {
    return sql`ROW(${value.bucket_id},${value.file_path})::file_attachment`;
  },
  fromDriver(value: string): FileAttachment {
    const [bucketId, filePath] = value.slice(1, -1).split(',');
    return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
  },
});

export function escapeLiteral(str: string): string {
  return "'" + str.replace(/'/g, "''") + "'";
}

export const userProfileArray = customType<{
  data: string[];
  driverData: string;
}>({
  dataType() {
    return 'user_profile[]';
  },
  toDriver(value: string[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::user_profile[]`;
    }
    const elements = value.map(id => `ROW(${escapeLiteral(id)})::user_profile`).join(',');
    return sql.raw(`ARRAY[${elements}]::user_profile[]`);
  },
  fromDriver(value: string): string[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => m.slice(1, -1).split(',')[0].trim());
  },
});

export const fileAttachmentArray = customType<{
  data: FileAttachment[];
  driverData: string;
}>({
  dataType() {
    return 'file_attachment[]';
  },
  toDriver(value: FileAttachment[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::file_attachment[]`;
    }
    const elements = value.map(f =>
      `ROW(${escapeLiteral(f.bucket_id)},${escapeLiteral(f.file_path)})::file_attachment`
    ).join(',');
    return sql.raw(`ARRAY[${elements}]::file_attachment[]`);
  },
  fromDriver(value: string): FileAttachment[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => {
      const [bucketId, filePath] = m.slice(1, -1).split(',');
      return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
    });
  },
});

export const apiKeys = pgTable("api_keys", {
  id: uuid("id").primaryKey().defaultRandom(),
  keyHash: varchar("key_hash", { length: 255 }).notNull().unique(),
  keyPrefix: varchar("key_prefix", { length: 20 }).notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  userId: uuid("user_id").notNull(),
  permission: varchar("permission", { length: 20 }).notNull().default('read'),
  quotaBytes: bigint("quota_bytes", { mode: 'number' }),
  usedBytes: bigint("used_bytes", { mode: 'number' }).notNull().default(0),
  expiresAt: customTimestamptz("expires_at", { precision: 3 }),
  callCount: integer("call_count").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("api_keys_key_hash_key").on(table.keyHash),
  index("idx_api_keys_key_hash").on(table.keyHash),
  index("idx_api_keys_user_id").on(table.userId),
  foreignKey({
    columns: [table.userId],
    foreignColumns: [users.id],
    name: "api_keys_user_id_fkey",
  }).onDelete("cascade"),
]);

export const shares = pgTable("shares", {
  id: uuid("id").primaryKey().defaultRandom(),
  token: varchar("token", { length: 50 }).notNull().unique(),
  fileId: uuid("file_id").notNull(),
  shareType: varchar("share_type", { length: 10 }).notNull().default('file'),
  password: varchar("password", { length: 255 }),
  expiresAt: customTimestamptz("expires_at", { precision: 3 }),
  allowDownload: boolean("allow_download").notNull().default(true),
  createdBy: uuid("created_by").notNull(),
  viewCount: integer("view_count").notNull().default(0),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("shares_token_key").on(table.token),
  index("idx_shares_token").on(table.token),
  foreignKey({
    columns: [table.fileId],
    foreignColumns: [files.id],
    name: "shares_file_id_fkey",
  }).onDelete("cascade"),
  foreignKey({
    columns: [table.createdBy],
    foreignColumns: [users.id],
    name: "shares_created_by_fkey",
  }).onDelete("cascade"),
]);

export const files = pgTable("files", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull(),
  name: varchar("name", { length: 500 }).notNull(),
  type: varchar("type", { length: 10 }).notNull().default('file'),
  parentId: uuid("parent_id"),
  filePath: text("file_path"),
  bucketId: varchar("bucket_id", { length: 255 }),
  sizeBytes: bigint("size_bytes", { mode: 'number' }).notNull().default(0),
  mimeType: varchar("mime_type", { length: 100 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_files_user_id").on(table.userId),
  index("idx_files_parent_id").on(table.parentId),
  index("idx_files_user_parent").on(table.userId, table.parentId),
  foreignKey({
    columns: [table.userId],
    foreignColumns: [users.id],
    name: "files_user_id_fkey",
  }).onDelete("cascade"),
  foreignKey({
    columns: [table.parentId],
    foreignColumns: [files.id],
    name: "files_parent_id_fkey",
  }).onDelete("cascade"),
]);

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  role: varchar("role", { length: 20 }).notNull().default('user'),
  quotaBytes: bigint("quota_bytes", { mode: 'number' }).notNull().default(1073741824),
  usedBytes: bigint("used_bytes", { mode: 'number' }).notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  canUpload: boolean("can_upload").notNull().default(true),
  canShare: boolean("can_share").notNull().default(true),
  canUseApi: boolean("can_use_api").notNull().default(false),
  allowedFileTypes: text("allowed_file_types").array(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("users_username_key").on(table.username),
]);

// table aliases
export const apiKeysTable = apiKeys;
export const filesTable = files;
export const sharesTable = shares;
export const usersTable = users;
