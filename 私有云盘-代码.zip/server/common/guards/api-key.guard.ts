import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ApiKeysService } from '@server/modules/api-keys/api-keys.service';
import { REQUIRE_API_PERMISSION_KEY } from '../decorators/require-api-permission.decorator';
import type { ApiPermission, ApiKeyInfo, UserInfo } from '@shared/api.interface';

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      apiKey?: ApiKeyInfo;
    }
  }
}

function hasRequiredPermission(
  keyPermission: ApiPermission,
  required: ApiPermission,
): boolean {
  if (required === 'read') {
    return keyPermission === 'read' || keyPermission === 'readwrite';
  }
  if (required === 'readwrite') {
    return keyPermission === 'readwrite';
  }
  return false;
}

@Injectable()
export class ApiKeyGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly apiKeysService: ApiKeysService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const apiKeyHeader: string | undefined = request.headers['x-api-key'];

    if (!apiKeyHeader) {
      throw new UnauthorizedException('未提供 API Key');
    }

    const result = await this.apiKeysService.validateApiKey(apiKeyHeader);

    const requiredPermission = this.reflector.getAllAndOverride<
      ApiPermission | undefined
    >(REQUIRE_API_PERMISSION_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (
      requiredPermission &&
      !hasRequiredPermission(result.apiKey.permission, requiredPermission)
    ) {
      throw new ForbiddenException('API Key 权限不足');
    }

    request.user = result.user as UserInfo;
    request.apiKey = result.apiKey;
    return true;
  }
}
