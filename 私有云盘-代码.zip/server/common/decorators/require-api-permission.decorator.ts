import { SetMetadata } from '@nestjs/common';
import type { ApiPermission } from '@shared/api.interface';

export const REQUIRE_API_PERMISSION_KEY = 'requireApiPermission';

export const RequireApiPermission = (permission: ApiPermission) =>
  SetMetadata(REQUIRE_API_PERMISSION_KEY, permission);
