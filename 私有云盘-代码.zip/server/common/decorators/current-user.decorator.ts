import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import type { UserInfo } from '@shared/api.interface';

export const CurrentUser = createParamDecorator(
  (data: unknown, ctx: ExecutionContext): UserInfo => {
    const request = ctx.switchToHttp().getRequest();
    return request.user as UserInfo;
  },
);
