import { Module } from '@nestjs/common';
import { ApiKeysController, OpenApiFilesController } from './api-keys.controller';
import { ApiKeysService } from './api-keys.service';
import { ApiKeyGuard } from '@server/common/guards/api-key.guard';

@Module({
  imports: [],
  controllers: [ApiKeysController, OpenApiFilesController],
  providers: [ApiKeysService, ApiKeyGuard],
  exports: [ApiKeysService, ApiKeyGuard],
})
export class ApiKeysModule {}
