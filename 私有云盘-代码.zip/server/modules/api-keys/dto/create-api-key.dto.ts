import {
  IsString,
  MinLength,
  IsOptional,
  IsIn,
  IsNumber,
} from 'class-validator';
import { Type } from 'class-transformer';
import { API_PERMISSIONS } from '@shared/api.interface';
import type { CreateApiKeyRequest, ApiPermission } from '@shared/api.interface';

export class CreateApiKeyDto implements CreateApiKeyRequest {
  @IsString()
  @MinLength(1)
  name!: string;

  @IsIn(API_PERMISSIONS)
  permission!: ApiPermission;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  quotaBytes?: number | null;

  @IsOptional()
  @IsString()
  expiresAt?: string | null;
}
