import { IsBoolean } from 'class-validator';

export class ToggleApiKeyDto {
  @IsBoolean()
  isActive!: boolean;
}
