import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
  UnauthorizedException,
  Inject,
} from '@nestjs/common';
import { eq, and, count, desc, sql } from 'drizzle-orm';
import { randomBytes, createHash } from 'node:crypto';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { apiKeys, users } from '@server/database/schema';
import type {
  ApiKeyInfo,
  CreateApiKeyRequest,
  CreateApiKeyResponse,
  UserInfo,
  ApiPermission,
} from '@shared/api.interface';

function toApiKeyInfo(row: typeof apiKeys.$inferSelect): ApiKeyInfo {
  return {
    id: row.id,
    name: row.name,
    keyPrefix: row.keyPrefix,
    permission: row.permission as ApiPermission,
    quotaBytes: row.quotaBytes !== null ? Number(row.quotaBytes) : null,
    usedBytes: Number(row.usedBytes),
    expiresAt: row.expiresAt ? row.expiresAt.toISOString() : null,
    callCount: row.callCount,
    isActive: row.isActive,
    createdAt: row.createdAt.toISOString(),
  };
}

function toUserInfo(row: typeof users.$inferSelect): UserInfo {
  return {
    id: row.id,
    username: row.username,
    role: row.role as UserInfo['role'],
    quotaBytes: Number(row.quotaBytes),
    usedBytes: Number(row.usedBytes),
    isActive: row.isActive,
    canUpload: row.canUpload,
    canShare: row.canShare,
    canUseApi: row.canUseApi,
    allowedFileTypes: row.allowedFileTypes ?? null,
    createdAt: row.createdAt.toISOString(),
  };
}

function generateApiKey(): string {
  const randomPart = randomBytes(32).toString('hex');
  return `sk_${randomPart}`;
}

function hashKey(key: string): string {
  return createHash('sha256').update(key).digest('hex');
}

export interface ValidatedApiKeyResult {
  user: UserInfo;
  apiKey: ApiKeyInfo;
}

@Injectable()
export class ApiKeysService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async create(
    userId: string,
    dto: CreateApiKeyRequest,
  ): Promise<CreateApiKeyResponse> {
    const userRows = await this.db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (userRows.length === 0) {
      throw new NotFoundException('用户不存在');
    }

    if (!userRows[0].canUseApi) {
      throw new ForbiddenException('您没有 API 使用权限');
    }

    const key = generateApiKey();
    const keyHash = hashKey(key);
    const keyPrefix = key.slice(0, 8);

    const insertData: typeof apiKeys.$inferInsert = {
      keyHash,
      keyPrefix,
      name: dto.name,
      userId,
      permission: dto.permission,
      quotaBytes: dto.quotaBytes ?? null,
      usedBytes: 0,
      expiresAt: dto.expiresAt ? new Date(dto.expiresAt) : null,
      callCount: 0,
      isActive: true,
    };

    const [created] = await this.db
      .insert(apiKeys)
      .values(insertData)
      .returning();

    return {
      apiKey: toApiKeyInfo(created),
      key,
    };
  }

  async list(
    userId: string,
    page: number = 1,
    pageSize: number = 20,
  ): Promise<{ items: ApiKeyInfo[]; total: number }> {
    const offset = (page - 1) * pageSize;

    const whereCondition = eq(apiKeys.userId, userId);

    const [totalResult, rows] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(apiKeys)
        .where(whereCondition),
      this.db
        .select()
        .from(apiKeys)
        .where(whereCondition)
        .orderBy(desc(apiKeys.createdAt))
        .limit(pageSize)
        .offset(offset),
    ]);

    const total = totalResult[0]?.count ?? 0;
    const items: ApiKeyInfo[] = rows.map((row: typeof apiKeys.$inferSelect) =>
      toApiKeyInfo(row),
    );

    return { items, total };
  }

  async remove(apiKeyId: string, userId: string): Promise<void> {
    const deleted = await this.db
      .delete(apiKeys)
      .where(and(eq(apiKeys.id, apiKeyId), eq(apiKeys.userId, userId)))
      .returning({ id: apiKeys.id });

    if (deleted.length === 0) {
      throw new NotFoundException('API Key 不存在');
    }
  }

  async toggleActive(
    apiKeyId: string,
    userId: string,
    isActive: boolean,
  ): Promise<ApiKeyInfo> {
    const updated = await this.db
      .update(apiKeys)
      .set({ isActive })
      .where(and(eq(apiKeys.id, apiKeyId), eq(apiKeys.userId, userId)))
      .returning();

    if (updated.length === 0) {
      throw new NotFoundException('API Key 不存在');
    }

    return toApiKeyInfo(updated[0]);
  }

  async validateApiKey(key: string): Promise<ValidatedApiKeyResult> {
    const keyHash = hashKey(key);

    const apiKeyRows = await this.db
      .select()
      .from(apiKeys)
      .where(eq(apiKeys.keyHash, keyHash))
      .limit(1);

    if (apiKeyRows.length === 0) {
      throw new UnauthorizedException('API Key 无效');
    }

    const apiKeyRow = apiKeyRows[0];

    if (!apiKeyRow.isActive) {
      throw new UnauthorizedException('API Key 已被禁用');
    }

    if (apiKeyRow.expiresAt && new Date(apiKeyRow.expiresAt) < new Date()) {
      throw new UnauthorizedException('API Key 已过期');
    }

    const userRows = await this.db
      .select()
      .from(users)
      .where(eq(users.id, apiKeyRow.userId))
      .limit(1);

    if (userRows.length === 0) {
      throw new UnauthorizedException('关联用户不存在');
    }

    const userRow = userRows[0];

    if (!userRow.isActive) {
      throw new UnauthorizedException('关联用户已被禁用');
    }

    await this.incrementCallCount(apiKeyRow.id);

    return {
      user: toUserInfo(userRow),
      apiKey: toApiKeyInfo(apiKeyRow),
    };
  }

  async incrementUsage(apiKeyId: string, bytes: number): Promise<void> {
    const newUsed = sql<number>`${apiKeys.usedBytes} + ${bytes}`;

    const updated = await this.db
      .update(apiKeys)
      .set({ usedBytes: newUsed })
      .where(and(
        eq(apiKeys.id, apiKeyId),
        sql`(
          ${apiKeys.quotaBytes} IS NULL 
          OR ${newUsed} <= ${apiKeys.quotaBytes}
        )`,
      ))
      .returning({ id: apiKeys.id });

    if (updated.length === 0) {
      const existing = await this.db
        .select({ id: apiKeys.id, quotaBytes: apiKeys.quotaBytes })
        .from(apiKeys)
        .where(eq(apiKeys.id, apiKeyId))
        .limit(1);

      if (existing.length === 0) {
        throw new NotFoundException('API Key 不存在');
      }
      throw new BadRequestException('API Key 配额不足');
    }
  }

  async incrementCallCount(apiKeyId: string): Promise<void> {
    await this.db
      .update(apiKeys)
      .set({ callCount: sql<number>`${apiKeys.callCount} + 1` })
      .where(eq(apiKeys.id, apiKeyId));
  }
}
