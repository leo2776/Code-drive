import {
  Controller,
  Post,
  Get,
  Delete,
  Patch,
  Body,
  Param,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import type { Request } from 'express';
import { ApiKeysService } from './api-keys.service';
import { CreateApiKeyDto } from './dto/create-api-key.dto';
import { ToggleApiKeyDto } from './dto/toggle-api-key.dto';
import { ApiKeyListQueryDto } from './dto/api-key-list-query.dto';
import { ApiKeyGuard } from '@server/common/guards/api-key.guard';
import { RequireApiPermission } from '@server/common/decorators/require-api-permission.decorator';
import { Public } from '@server/common/decorators/public.decorator';
import type {
  ApiKeyInfo,
  CreateApiKeyResponse,
  FileItem,
  FileListRequest,
  FileListResponse,
  UploadResponse,
} from '@shared/api.interface';

@Controller('api/api-keys')
export class ApiKeysController {
  constructor(private readonly apiKeysService: ApiKeysService) {}

  @Post()
  async create(
    @Req() req: Request,
    @Body() dto: CreateApiKeyDto,
  ): Promise<CreateApiKeyResponse> {
    return this.apiKeysService.create(req.user.id, dto);
  }

  @Get()
  async list(
    @Req() req: Request,
    @Query() query: ApiKeyListQueryDto,
  ): Promise<{ items: ApiKeyInfo[]; total: number; page: number; pageSize: number }> {
    const result = await this.apiKeysService.list(req.user.id, query.page, query.pageSize);
    return { ...result, page: query.page, pageSize: query.pageSize };
  }

  @Delete(':id')
  async remove(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<{ success: boolean }> {
    await this.apiKeysService.remove(id, req.user.id);
    return { success: true };
  }

  @Patch(':id/toggle')
  async toggleActive(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: ToggleApiKeyDto,
  ): Promise<ApiKeyInfo> {
    return this.apiKeysService.toggleActive(id, req.user.id, dto.isActive);
  }
}

@Controller('openapi/files')
@Public()
@UseGuards(ApiKeyGuard)
export class OpenApiFilesController {
  constructor(private readonly apiKeysService: ApiKeysService) {}

  private getUserId(req: Request): string {
    return req.user.id;
  }

  @Get()
  @RequireApiPermission('read')
  async listFiles(
    @Req() req: Request,
    @Query() query: FileListRequest,
  ): Promise<FileListResponse> {
    // Note: This endpoint relies on FilesService.
    // Since FilesService is not yet available, this implementation returns an empty list.
    // Once FilesModule is created, inject FilesService and delegate to it.
    const userId = this.getUserId(req);
    void userId;
    void query;
    return { items: [], currentPath: [] };
  }

  @Post('upload-complete')
  @RequireApiPermission('readwrite')
  async uploadComplete(
    @Req() req: Request,
    @Body() body: { fileId: string; sizeBytes: number },
  ): Promise<UploadResponse> {
    // Placeholder — delegate to FilesService once available
    // After successful upload, increment API key usage:
    // if (req.apiKey) {
    //   await this.apiKeysService.incrementUsage(req.apiKey.id, body.sizeBytes);
    // }
    void req;
    void body;
    throw new Error('FilesService not yet available');
  }

  @Get(':id/download-url')
  @RequireApiPermission('read')
  async getDownloadUrl(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<{ downloadUrl: string }> {
    // Placeholder — delegate to FilesService once available
    void req;
    void id;
    throw new Error('FilesService not yet available');
  }

  @Get(':id')
  @RequireApiPermission('read')
  async getFile(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<FileItem> {
    // Placeholder — delegate to FilesService once available
    void req;
    void id;
    throw new Error('FilesService not yet available');
  }

  @Delete(':id')
  @RequireApiPermission('readwrite')
  async deleteFile(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<{ success: boolean }> {
    // Placeholder — delegate to FilesService once available
    void req;
    void id;
    throw new Error('FilesService not yet available');
  }
}
