import { Controller, Post, Get, Body, HttpCode, HttpStatus } from '@nestjs/common';
import { AuthService } from './auth.service';
import { InitDto } from './dto/init.dto';
import { LoginDto } from './dto/login.dto';
import { Public } from '@server/common/decorators/public.decorator';
import { CurrentUser } from '@server/common/decorators/current-user.decorator';
import type {
  InitResponse,
  LoginResponse,
  UserInfo,
} from '@shared/api.interface';

@Controller('api/auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Public()
  @Post('init')
  @HttpCode(HttpStatus.OK)
  async init(@Body() dto: InitDto): Promise<InitResponse> {
    return this.authService.init(dto.username, dto.password);
  }

  @Public()
  @Get('status')
  async getStatus(): Promise<{ initialized: boolean }> {
    const initialized = await this.authService.isInitialized();
    return { initialized };
  }

  @Public()
  @Post('login')
  @HttpCode(HttpStatus.OK)
  async login(@Body() dto: LoginDto): Promise<LoginResponse> {
    return this.authService.login(dto.username, dto.password);
  }

  @Get('me')
  async me(@CurrentUser() user: UserInfo): Promise<UserInfo> {
    return user;
  }

  @Post('logout')
  @HttpCode(HttpStatus.OK)
  async logout(): Promise<{ success: boolean }> {
    return { success: true };
  }
}
