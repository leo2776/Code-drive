import { BadRequestException, Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { count, eq } from 'drizzle-orm';
import { scrypt, randomBytes, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { users } from '@server/database/schema';
import { sign as jwtSign, verify as jwtVerify } from './jwt.util';
import type {
  InitResponse,
  LoginResponse,
  UserInfo,
  UserRole,
} from '@shared/api.interface';

const scryptAsync = promisify(scrypt);

const PASSWORD_SALT_LEN = 16;
const PASSWORD_KEY_LEN = 64;
const JWT_SECRET = process.env.JWT_SECRET ?? 'cloud-drive-dev-secret-change-me';
const JWT_EXPIRES_IN = 7 * 24 * 60 * 60; // 7 days in seconds

export interface JwtPayload {
  sub: string;
  username: string;
  role: UserRole;
}

@Injectable()
export class AuthService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async hashPassword(password: string): Promise<string> {
    const salt = randomBytes(PASSWORD_SALT_LEN).toString('hex');
    const derivedKey = (await scryptAsync(password, salt, PASSWORD_KEY_LEN)) as Buffer;
    return `${salt}:${derivedKey.toString('hex')}`;
  }

  async verifyPassword(password: string, passwordHash: string): Promise<boolean> {
    const [salt, keyHex] = passwordHash.split(':');
    if (!salt || !keyHex) return false;
    const derivedKey = (await scryptAsync(password, salt, PASSWORD_KEY_LEN)) as Buffer;
    const keyBuffer = Buffer.from(keyHex, 'hex');
    if (derivedKey.length !== keyBuffer.length) return false;
    return timingSafeEqual(derivedKey, keyBuffer);
  }

  signToken(payload: JwtPayload): string {
    return jwtSign(payload as unknown as Record<string, unknown>, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
  }

  verifyToken(token: string): JwtPayload | null {
    try {
      const result = jwtVerify(token, JWT_SECRET);
      if (!result) return null;
      return result as unknown as JwtPayload;
    } catch {
      return null;
    }
  }

  async init(username: string, password: string): Promise<InitResponse> {
    const countResult = await this.db.select({ count: count() }).from(users);
    const userCount = Number(countResult[0]?.count ?? 0);

    if (userCount > 0) {
      throw new BadRequestException('系统已初始化，禁止重复初始化');
    }

    const passwordHash = await this.hashPassword(password);
    const createdUsers = await this.db.insert(users).values({
      username,
      passwordHash,
      role: 'admin',
      quotaBytes: 1125899906842624, // 1 PB，管理员无限制
      usedBytes: 0,
      isActive: true,
      canUpload: true,
      canShare: true,
      canUseApi: true,
    }).returning();

    const created = createdUsers[0];
    if (!created) throw new BadRequestException('创建管理员用户失败');

    const userInfo = this.toUserInfo(created);
    const token = this.signToken({
      sub: created.id,
      username: created.username,
      role: created.role as UserRole,
    });

    return { token, user: userInfo };
  }

  async isInitialized(): Promise<boolean> {
    const countResult = await this.db.select({ count: count() }).from(users);
    const userCount = Number(countResult[0]?.count ?? 0);
    return userCount > 0;
  }

  async login(username: string, password: string): Promise<LoginResponse> {
    const foundUsers = await this.db.select().from(users).where(eq(users.username, username));
    const found = foundUsers[0];

    if (!found) {
      throw new UnauthorizedException('用户名或密码错误');
    }

    const passwordValid = await this.verifyPassword(password, found.passwordHash);
    if (!passwordValid) {
      throw new UnauthorizedException('用户名或密码错误');
    }

    if (!found.isActive) {
      throw new UnauthorizedException('账号已被禁用');
    }

    const userInfo = this.toUserInfo(found);
    const token = this.signToken({
      sub: found.id,
      username: found.username,
      role: found.role as UserRole,
    });

    return { token, user: userInfo };
  }

  async getUserById(userId: string): Promise<UserInfo | null> {
    const foundUsers = await this.db.select().from(users).where(eq(users.id, userId));
    const found = foundUsers[0];
    if (!found) return null;
    return this.toUserInfo(found);
  }

  private toUserInfo(row: typeof users.$inferSelect): UserInfo {
    return {
      id: row.id,
      username: row.username,
      role: row.role as UserRole,
      quotaBytes: Number(row.quotaBytes),
      usedBytes: Number(row.usedBytes),
      isActive: row.isActive,
      canUpload: row.canUpload,
      canShare: row.canShare,
      canUseApi: row.canUseApi,
      allowedFileTypes: row.allowedFileTypes ?? null,
      createdAt: row.createdAt.toISOString(),
    };
  }
}
