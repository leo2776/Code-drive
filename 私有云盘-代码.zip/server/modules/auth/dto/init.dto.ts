import { IsString, MinLength } from 'class-validator';
import type { InitRequest } from '@shared/api.interface';

export class InitDto implements InitRequest {
  @IsString()
  @MinLength(3)
  username!: string;

  @IsString()
  @MinLength(6)
  password!: string;
}
