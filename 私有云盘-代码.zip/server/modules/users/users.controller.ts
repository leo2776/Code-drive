import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  Req,
  ForbiddenException,
} from '@nestjs/common';
import type { Request } from 'express';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UserListQueryDto } from './dto/user-list-query.dto';
import type { UserInfo, UserListResponse } from '@shared/api.interface';

@Controller('api/users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  private checkAdmin(req: Request): void {
    if (req.user.role !== 'admin') {
      throw new ForbiddenException('需要管理员权限');
    }
  }

  @Get()
  async list(
    @Req() req: Request,
    @Query() query: UserListQueryDto,
  ): Promise<UserListResponse> {
    this.checkAdmin(req);
    return this.usersService.list(query.page, query.pageSize, query.search);
  }

  @Get(':id')
  async getById(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<UserInfo> {
    this.checkAdmin(req);
    return this.usersService.getById(id);
  }

  @Post()
  async create(
    @Req() req: Request,
    @Body() dto: CreateUserDto,
  ): Promise<UserInfo> {
    this.checkAdmin(req);
    return this.usersService.create(dto);
  }

  @Patch(':id')
  async update(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateUserDto,
  ): Promise<UserInfo> {
    this.checkAdmin(req);
    return this.usersService.update(id, dto);
  }

  @Delete(':id')
  async remove(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<{ success: boolean }> {
    this.checkAdmin(req);
    await this.usersService.remove(id);
    return { success: true };
  }
}
