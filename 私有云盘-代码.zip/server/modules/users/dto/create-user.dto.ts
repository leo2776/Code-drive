import {
  IsString,
  MinLength,
  IsOptional,
  IsIn,
  IsBoolean,
  IsNumber,
  IsArray,
} from 'class-validator';
import { Type } from 'class-transformer';
import { USER_ROLES } from '@shared/api.interface';
import type { CreateUserRequest, UserRole } from '@shared/api.interface';

export class CreateUserDto implements CreateUserRequest {
  @IsString()
  @MinLength(3)
  username!: string;

  @IsString()
  @MinLength(6)
  password!: string;

  @IsOptional()
  @IsIn(USER_ROLES)
  role?: UserRole;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  quotaBytes?: number;

  @IsOptional()
  @IsBoolean()
  canUpload?: boolean;

  @IsOptional()
  @IsBoolean()
  canShare?: boolean;

  @IsOptional()
  @IsBoolean()
  canUseApi?: boolean;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  allowedFileTypes?: string[];
}
