import {
  IsString,
  MinLength,
  IsOptional,
  IsIn,
  IsBoolean,
  IsNumber,
  IsArray,
} from 'class-validator';
import { Type } from 'class-transformer';
import { USER_ROLES } from '@shared/api.interface';
import type { UpdateUserRequest, UserRole } from '@shared/api.interface';

export class UpdateUserDto implements UpdateUserRequest {
  @IsOptional()
  @IsString()
  @MinLength(6)
  password?: string;

  @IsOptional()
  @IsIn(USER_ROLES)
  role?: UserRole;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  quotaBytes?: number;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;

  @IsOptional()
  @IsBoolean()
  canUpload?: boolean;

  @IsOptional()
  @IsBoolean()
  canShare?: boolean;

  @IsOptional()
  @IsBoolean()
  canUseApi?: boolean;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  allowedFileTypes?: string[];
}
