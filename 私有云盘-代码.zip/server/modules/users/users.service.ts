import {
  ConflictException,
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { eq, ilike, count, and, gte, sql } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { Inject } from '@nestjs/common';
import { users } from '@server/database/schema';
import { AuthService } from '../auth/auth.service';
import type {
  UserInfo,
  UserListResponse,
  CreateUserRequest,
  UpdateUserRequest,
} from '@shared/api.interface';

const DEFAULT_QUOTA_BYTES = 1099511627776; // 1 TB

function extractPostgresErrorCode(error: unknown): string | undefined {
  let current: unknown = error;
  for (let depth = 0; depth < 4 && current && typeof current === 'object'; depth += 1) {
    const { code, cause } = current as { code?: unknown; cause?: unknown };
    if (typeof code === 'string') return code;
    current = cause;
  }
  return undefined;
}

function toUserInfo(row: typeof users.$inferSelect): UserInfo {
  return {
    id: row.id,
    username: row.username,
    role: row.role as UserInfo['role'],
    quotaBytes: row.quotaBytes,
    usedBytes: row.usedBytes,
    isActive: row.isActive,
    canUpload: row.canUpload,
    canShare: row.canShare,
    canUseApi: row.canUseApi,
    allowedFileTypes: row.allowedFileTypes ?? null,
    createdAt: row.createdAt.toISOString(),
  };
}

@Injectable()
export class UsersService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
    private readonly authService: AuthService,
  ) {}

  async list(page: number, pageSize: number, search?: string): Promise<UserListResponse> {
    const offset = (page - 1) * pageSize;
    const whereCondition = search
      ? ilike(users.username, `%${search}%`)
      : undefined;

    const baseCountQuery = this.db.select({ count: count() }).from(users);
    const baseListQuery = this.db
      .select()
      .from(users)
      .orderBy(users.createdAt)
      .limit(pageSize)
      .offset(offset);

    const countQuery = whereCondition
      ? baseCountQuery.where(whereCondition)
      : baseCountQuery;
    const listQuery = whereCondition
      ? baseListQuery.where(whereCondition)
      : baseListQuery;

    const [totalResult, rows] = await Promise.all([countQuery, listQuery]);

    const total = totalResult[0]?.count ?? 0;
    const items: UserInfo[] = rows.map((row: typeof users.$inferSelect) => toUserInfo(row));

    return { items, total };
  }

  async getById(id: string): Promise<UserInfo> {
    const rows = await this.db.select().from(users).where(eq(users.id, id)).limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('用户不存在');
    }
    return toUserInfo(rows[0]);
  }

  async create(dto: CreateUserRequest): Promise<UserInfo> {
    const passwordHash = await this.authService.hashPassword(dto.password);

    const insertData: typeof users.$inferInsert = {
      username: dto.username,
      passwordHash,
      role: dto.role ?? 'user',
      quotaBytes: dto.quotaBytes ?? DEFAULT_QUOTA_BYTES,
      canUpload: dto.canUpload ?? true,
      canShare: dto.canShare ?? true,
      canUseApi: dto.canUseApi ?? false,
      allowedFileTypes: dto.allowedFileTypes ?? null,
    };

    try {
      const [row] = await this.db.insert(users).values(insertData).returning();
      return toUserInfo(row);
    } catch (error: unknown) {
      const code = extractPostgresErrorCode(error);
      if (code === '23505') {
        throw new ConflictException('用户名已存在');
      }
      throw error;
    }
  }

  async update(id: string, dto: UpdateUserRequest): Promise<UserInfo> {
    const patch: Partial<typeof users.$inferInsert> = {};

    if (dto.password !== undefined) {
      patch.passwordHash = await this.authService.hashPassword(dto.password);
    }
    if (dto.role !== undefined) patch.role = dto.role;
    if (dto.quotaBytes !== undefined) patch.quotaBytes = dto.quotaBytes;
    if (dto.isActive !== undefined) patch.isActive = dto.isActive;
    if (dto.canUpload !== undefined) patch.canUpload = dto.canUpload;
    if (dto.canShare !== undefined) patch.canShare = dto.canShare;
    if (dto.canUseApi !== undefined) patch.canUseApi = dto.canUseApi;
    if (dto.allowedFileTypes !== undefined) {
      patch.allowedFileTypes = dto.allowedFileTypes;
    }

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(users)
      .set(patch)
      .where(eq(users.id, id))
      .returning();

    if (updated.length === 0) {
      throw new NotFoundException('用户不存在');
    }

    return toUserInfo(updated[0]);
  }

  async remove(id: string): Promise<void> {
    const deleted = await this.db
      .delete(users)
      .where(eq(users.id, id))
      .returning({ id: users.id });

    if (deleted.length === 0) {
      throw new NotFoundException('用户不存在');
    }
  }

  async toggleActive(id: string, isActive: boolean): Promise<UserInfo> {
    const updated = await this.db
      .update(users)
      .set({ isActive })
      .where(eq(users.id, id))
      .returning();

    if (updated.length === 0) {
      throw new NotFoundException('用户不存在');
    }

    return toUserInfo(updated[0]);
  }

  async updateUsedBytes(userId: string, delta: number): Promise<void> {
    const newUsed = sql<number>`${users.usedBytes} + ${delta}`;
    const result = await this.db
      .update(users)
      .set({ usedBytes: newUsed })
      .where(and(eq(users.id, userId), gte(newUsed, 0)))
      .returning({ id: users.id });

    if (result.length === 0) {
      throw new BadRequestException('存储空间不足或用户不存在');
    }
  }

  async checkQuota(userId: string, fileSize: number): Promise<boolean> {
    const rows = await this.db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('用户不存在');
    }
    const user = rows[0];
    // 管理员角色不受配额限制
    if (user.role === 'admin') return true;
    return Number(user.usedBytes) + fileSize <= Number(user.quotaBytes);
  }

  async ensureAdmin(userId: string): Promise<void> {
    const rows = await this.db
      .select({ role: users.role })
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('用户不存在');
    }
    if (rows[0].role !== 'admin') {
      throw new ForbiddenException('需要管理员权限');
    }
  }
}
