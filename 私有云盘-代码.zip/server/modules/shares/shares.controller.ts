import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Query,
} from '@nestjs/common';
import { SharesService } from './shares.service';
import { CreateShareDto } from './dto/create-share.dto';
import { ShareAccessDto } from './dto/share-access.dto';
import { ShareListQueryDto } from './dto/share-list-query.dto';
import { Public } from '@server/common/decorators/public.decorator';
import { CurrentUser } from '@server/common/decorators/current-user.decorator';
import type {
  CreateShareResponse,
  ShareAccessResponse,
  ShareInfo,
  UserInfo,
} from '@shared/api.interface';

interface ShareListResponse {
  items: ShareInfo[];
  total: number;
  page: number;
  pageSize: number;
}

interface ShareFolderChildrenResponse {
  items: import('@shared/api.interface').FileItem[];
  share: Omit<ShareInfo, 'token'>;
  needPassword: boolean;
}

@Controller('api/shares')
export class SharesController {
  constructor(private readonly sharesService: SharesService) {}

  @Post()
  async create(
    @CurrentUser() user: UserInfo,
    @Body() dto: CreateShareDto,
  ): Promise<CreateShareResponse> {
    return this.sharesService.create(
      user.id,
      dto.fileId,
      dto.password,
      dto.expiresAt,
      dto.allowDownload,
    );
  }

  @Get()
  async listMyShares(
    @CurrentUser() user: UserInfo,
    @Query() query: ShareListQueryDto,
  ): Promise<ShareListResponse> {
    return this.sharesService.listByUser(user.id, query.page, query.pageSize);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  async remove(
    @CurrentUser() user: UserInfo,
    @Param('id') id: string,
  ): Promise<void> {
    await this.sharesService.remove(id, user.id, user.role);
  }

  // Public routes
  @Public()
  @Get('public/:token/info')
  async getShareInfo(@Param('token') token: string): Promise<ShareInfo> {
    return this.sharesService.getByToken(token);
  }

  @Public()
  @Post('public/:token/access')
  @HttpCode(HttpStatus.OK)
  async accessShare(
    @Param('token') token: string,
    @Body() dto: ShareAccessDto,
  ): Promise<ShareAccessResponse | ShareFolderChildrenResponse> {
    // First get the share info to determine if it's a file or folder
    const accessResult = await this.sharesService.getShareFile(token, dto.password);

    // If it's a folder, return the children
    if (accessResult.file.type === 'folder') {
      return this.sharesService.getShareChildren(token, dto.password);
    }

    return accessResult;
  }
}
