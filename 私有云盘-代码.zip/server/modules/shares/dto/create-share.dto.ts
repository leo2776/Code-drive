import { IsBoolean, IsOptional, IsString, IsUUID } from 'class-validator';
import type { CreateShareRequest } from '@shared/api.interface';

export class CreateShareDto implements CreateShareRequest {
  @IsUUID()
  fileId!: string;

  @IsOptional()
  @IsString()
  password?: string;

  @IsOptional()
  @IsString()
  expiresAt?: string | null;

  @IsOptional()
  @IsBoolean()
  allowDownload?: boolean;
}
