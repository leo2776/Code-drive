import {
  BadRequestException,
  ForbiddenException,
  Inject,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { count, desc, eq } from 'drizzle-orm';
import { scrypt, randomBytes, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { files, shares, users } from '@server/database/schema';
import type {
  CreateShareResponse,
  FileItem,
  ShareAccessResponse,
  ShareInfo,
  ShareType,
} from '@shared/api.interface';

const scryptAsync = promisify(scrypt);

const PASSWORD_SALT_LEN = 16;
const PASSWORD_KEY_LEN = 64;
const TOKEN_LENGTH = 16;
const DEFAULT_PAGE = 1;
const DEFAULT_PAGE_SIZE = 20;

@Injectable()
export class SharesService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async create(
    userId: string,
    fileId: string,
    password?: string,
    expiresAt?: string | null,
    allowDownload?: boolean,
  ): Promise<CreateShareResponse> {
    // Check user permissions
    const userRows = await this.db.select().from(users).where(eq(users.id, userId));
    const user = userRows[0];
    if (!user) throw new NotFoundException('用户不存在');
    if (!user.canShare) throw new ForbiddenException('您没有分享权限');

    // Check file exists and user is owner or admin
    const fileRows = await this.db.select().from(files).where(eq(files.id, fileId));
    const file = fileRows[0];
    if (!file) throw new NotFoundException('文件不存在');

    const isAdmin = user.role === 'admin';
    if (file.userId !== userId && !isAdmin) {
      throw new ForbiddenException('只有文件所有者或管理员可以创建分享');
    }

    // Hash password if provided
    let passwordHash: string | undefined;
    if (password && password.length > 0) {
      passwordHash = await this.hashPassword(password);
    }

    // Generate random token
    const token = this.generateToken();

    // Parse expiresAt
    const expiresAtDate = expiresAt ? new Date(expiresAt) : null;
    if (expiresAt && isNaN(expiresAtDate.getTime())) {
      throw new BadRequestException('过期时间格式无效');
    }

    const inserted = await this.db.insert(shares).values({
      token,
      fileId,
      shareType: file.type as ShareType,
      password: passwordHash ?? null,
      expiresAt: expiresAtDate,
      allowDownload: allowDownload ?? true,
      createdBy: userId,
      viewCount: 0,
    }).returning();

    const created = inserted[0];
    if (!created) throw new BadRequestException('创建分享失败');

    const shareInfo = await this.toShareInfo(created, file.name);

    return {
      share: shareInfo,
      shareUrl: `/share/${token}`,
    };
  }

  async getByToken(token: string): Promise<ShareInfo> {
    const result = await this.db
      .select({ share: shares, fileName: files.name })
      .from(shares)
      .innerJoin(files, eq(shares.fileId, files.id))
      .where(eq(shares.token, token));

    const row = result[0];
    if (!row) throw new NotFoundException('分享不存在');

    // Check expiration
    if (row.share.expiresAt && new Date(row.share.expiresAt) < new Date()) {
      throw new NotFoundException('分享已过期');
    }

    // Increment view count
    await this.db
      .update(shares)
      .set({ viewCount: row.share.viewCount + 1 })
      .where(eq(shares.id, row.share.id));

    return this.toShareInfo(row.share, row.fileName);
  }

  async verifyPassword(token: string, password: string): Promise<boolean> {
    const shareRows = await this.db.select().from(shares).where(eq(shares.token, token));
    const share = shareRows[0];
    if (!share) throw new NotFoundException('分享不存在');

    if (share.expiresAt && new Date(share.expiresAt) < new Date()) {
      throw new NotFoundException('分享已过期');
    }

    if (!share.password) {
      return true;
    }

    return this.verifyPasswordHash(password, share.password);
  }

  async listByUser(
    userId: string,
    page?: number,
    pageSize?: number,
  ): Promise<{ items: ShareInfo[]; total: number; page: number; pageSize: number }> {
    const currentPage = page ?? DEFAULT_PAGE;
    const currentPageSize = pageSize ?? DEFAULT_PAGE_SIZE;
    const offset = (currentPage - 1) * currentPageSize;

    const countResult = await this.db
      .select({ count: count() })
      .from(shares)
      .where(eq(shares.createdBy, userId));
    const total = Number(countResult[0]?.count ?? 0);

    const results = await this.db
      .select({ share: shares, fileName: files.name })
      .from(shares)
      .innerJoin(files, eq(shares.fileId, files.id))
      .where(eq(shares.createdBy, userId))
      .orderBy(desc(shares.createdAt))
      .limit(currentPageSize)
      .offset(offset);

    const items: ShareInfo[] = results.map((row: { share: typeof shares.$inferSelect; fileName: string }) =>
      this.toShareInfo(row.share, row.fileName),
    );

    return { items, total, page: currentPage, pageSize: currentPageSize };
  }

  async remove(shareId: string, userId: string, userRole: string): Promise<{ success: boolean }> {
    const shareRows = await this.db.select().from(shares).where(eq(shares.id, shareId));
    const share = shareRows[0];
    if (!share) throw new NotFoundException('分享不存在');

    const isAdmin = userRole === 'admin';
    if (share.createdBy !== userId && !isAdmin) {
      throw new ForbiddenException('只有分享创建者或管理员可以删除');
    }

    await this.db.delete(shares).where(eq(shares.id, shareId));

    return { success: true };
  }

  async getShareFile(
    token: string,
    password?: string,
  ): Promise<ShareAccessResponse> {
    const result = await this.db
      .select({ share: shares, file: files })
      .from(shares)
      .innerJoin(files, eq(shares.fileId, files.id))
      .where(eq(shares.token, token));

    const row = result[0];
    if (!row) throw new NotFoundException('分享不存在');

    // Check expiration
    if (row.share.expiresAt && new Date(row.share.expiresAt) < new Date()) {
      throw new NotFoundException('分享已过期');
    }

    // Check password
    const hasPassword = !!row.share.password;
    if (hasPassword) {
      if (!password) {
        throw new UnauthorizedException('需要分享密码');
      }
      const passwordValid = await this.verifyPasswordHash(password, row.share.password);
      if (!passwordValid) {
        throw new UnauthorizedException('分享密码错误');
      }
    }

    const fileItem = this.toFileItem(row.file);
    const shareInfo = this.toShareInfo(row.share, row.file.name);

    return {
      file: fileItem,
      share: this.omitToken(shareInfo),
      needPassword: hasPassword,
    };
  }

  async getShareChildren(
    token: string,
    password?: string,
  ): Promise<{ items: FileItem[]; share: Omit<ShareInfo, 'token'>; needPassword: boolean }> {
    // First verify access
    const accessResult = await this.getShareFile(token, password);
    if (accessResult.file.type !== 'folder') {
      throw new BadRequestException('该分享不是文件夹');
    }

    // List children of the folder
    const children = await this.db
      .select()
      .from(files)
      .where(eq(files.parentId, accessResult.file.id))
      .orderBy(desc(files.createdAt));

    const items: FileItem[] = children.map((child: typeof files.$inferSelect) => this.toFileItem(child));

    return {
      items,
      share: accessResult.share,
      needPassword: accessResult.needPassword,
    };
  }

  private generateToken(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const bytes = randomBytes(TOKEN_LENGTH);
    let result = '';
    for (let i = 0; i < TOKEN_LENGTH; i += 1) {
      result += chars[bytes[i] % chars.length];
    }
    return result;
  }

  private async hashPassword(password: string): Promise<string> {
    const salt = randomBytes(PASSWORD_SALT_LEN).toString('hex');
    const derivedKey = (await scryptAsync(password, salt, PASSWORD_KEY_LEN)) as Buffer;
    return `${salt}:${derivedKey.toString('hex')}`;
  }

  private async verifyPasswordHash(password: string, passwordHash: string): Promise<boolean> {
    const [salt, keyHex] = passwordHash.split(':');
    if (!salt || !keyHex) return false;
    const derivedKey = (await scryptAsync(password, salt, PASSWORD_KEY_LEN)) as Buffer;
    const keyBuffer = Buffer.from(keyHex, 'hex');
    if (derivedKey.length !== keyBuffer.length) return false;
    return timingSafeEqual(derivedKey, keyBuffer);
  }

  private toShareInfo(row: typeof shares.$inferSelect, fileName: string): ShareInfo {
    return {
      id: row.id,
      token: row.token,
      fileId: row.fileId,
      fileName,
      shareType: row.shareType as ShareType,
      hasPassword: !!row.password,
      expiresAt: row.expiresAt ? row.expiresAt.toISOString() : null,
      allowDownload: row.allowDownload,
      createdBy: row.createdBy,
      viewCount: row.viewCount,
      createdAt: row.createdAt.toISOString(),
    };
  }

  private omitToken(info: ShareInfo): Omit<ShareInfo, 'token'> {
    const { token: _token, ...rest } = info;
    return rest;
  }

  private toFileItem(row: typeof files.$inferSelect): FileItem {
    return {
      id: row.id,
      name: row.name,
      type: row.type as 'file' | 'folder',
      parentId: row.parentId ?? null,
      sizeBytes: Number(row.sizeBytes),
      mimeType: row.mimeType ?? null,
      userId: row.userId,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }
}
