import {
  Injectable,
  NotFoundException,
  ConflictException,
  BadRequestException,
} from '@nestjs/common';
import { eq, and, ilike, asc, desc, sql, inArray } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { Inject } from '@nestjs/common';
import { files } from '@server/database/schema';
import { UsersService } from '../users/users.service';
import type {
  FileItem,
  FileListResponse,
} from '@shared/api.interface';

type FileRow = typeof files.$inferSelect;

function toFileItem(row: FileRow): FileItem {
  return {
    id: row.id,
    name: row.name,
    type: row.type as FileItem['type'],
    parentId: row.parentId ?? null,
    sizeBytes: Number(row.sizeBytes),
    mimeType: row.mimeType ?? null,
    userId: row.userId,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

@Injectable()
export class FilesService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
    private readonly usersService: UsersService,
  ) {}

  async list(
    userId: string,
    parentId: string | null,
    sortBy: 'name' | 'sizeBytes' | 'createdAt' | 'updatedAt' | 'type' = 'name',
    sortOrder: 'asc' | 'desc' = 'asc',
    search?: string,
    type?: 'file' | 'folder',
  ): Promise<FileListResponse> {
    const conditions = [eq(files.userId, userId)];

    if (search) {
      conditions.push(ilike(files.name, `%${search}%`));
      // search mode: recursive, no parent filter
    } else {
      if (parentId === null) {
        conditions.push(sql`${files.parentId} is null`);
      } else {
        conditions.push(eq(files.parentId, parentId));
      }
    }

    if (type) {
      conditions.push(eq(files.type, type));
    }

    const sortColumn = this.getSortColumn(sortBy);
    const sortFn = sortOrder === 'asc' ? asc : desc;

    const rows: FileRow[] = await this.db
      .select()
      .from(files)
      .where(and(...conditions))
      .orderBy(sortFn(sortColumn));

    const items: FileItem[] = rows.map((row: FileRow) => toFileItem(row));

    // Build breadcrumb path (only when not in search mode and parentId is not root)
    let currentPath: { id: string | null; name: string }[] = [
      { id: null, name: '全部文件' },
    ];

    if (!search && parentId !== null) {
      const pathSegments = await this.buildPath(parentId, userId);
      currentPath = [...currentPath, ...pathSegments];
    }

    return { items, currentPath };
  }

  private getSortColumn(
    sortBy: 'name' | 'sizeBytes' | 'createdAt' | 'updatedAt' | 'type',
  ) {
    switch (sortBy) {
      case 'name':
        return files.name;
      case 'sizeBytes':
        return files.sizeBytes;
      case 'createdAt':
        return files.createdAt;
      case 'updatedAt':
        return files.updatedAt;
      case 'type':
        return files.type;
      default:
        return files.name;
    }
  }

  private async buildPath(
    folderId: string,
    userId: string,
  ): Promise<{ id: string; name: string }[]> {
    const path: { id: string; name: string }[] = [];
    let currentId: string | null = folderId;

    while (currentId !== null) {
      const rows = await this.db
        .select({ id: files.id, name: files.name, parentId: files.parentId })
        .from(files)
        .where(and(eq(files.id, currentId), eq(files.userId, userId)))
        .limit(1);

      if (rows.length === 0) break;

      const row = rows[0];
      path.unshift({ id: row.id, name: row.name });
      currentId = row.parentId ?? null;
    }

    return path;
  }

  async getById(fileId: string, userId: string): Promise<FileItem> {
    const rows = await this.db
      .select()
      .from(files)
      .where(and(eq(files.id, fileId), eq(files.userId, userId)))
      .limit(1);

    if (rows.length === 0) {
      throw new NotFoundException('文件不存在');
    }

    return toFileItem(rows[0]);
  }

  async createFolder(
    userId: string,
    name: string,
    parentId: string | null = null,
  ): Promise<FileItem> {
    // Validate parent exists (if not root)
    if (parentId !== null) {
      const parentRows = await this.db
        .select()
        .from(files)
        .where(and(eq(files.id, parentId), eq(files.userId, userId)))
        .limit(1);
      if (parentRows.length === 0) {
        throw new NotFoundException('父目录不存在');
      }
      if (parentRows[0].type !== 'folder') {
        throw new BadRequestException('父节点不是文件夹');
      }
    }

    // Check for duplicate name in same parent
    const duplicateCondition = this.buildDuplicateCondition(userId, parentId, name);
    const existing = await this.db
      .select({ id: files.id })
      .from(files)
      .where(duplicateCondition)
      .limit(1);

    if (existing.length > 0) {
      throw new ConflictException('同名文件或文件夹已存在');
    }

    const [row] = await this.db
      .insert(files)
      .values({
        userId,
        name,
        type: 'folder',
        parentId,
        sizeBytes: 0,
      })
      .returning();

    return toFileItem(row);
  }

  async rename(fileId: string, userId: string, newName: string): Promise<FileItem> {
    const file = await this.getById(fileId, userId);

    // Check for duplicate name in same parent
    const duplicateCondition = this.buildDuplicateCondition(
      userId,
      file.parentId,
      newName,
    );
    const existing = await this.db
      .select({ id: files.id })
      .from(files)
      .where(and(duplicateCondition, sql`${files.id} != ${fileId}`))
      .limit(1);

    if (existing.length > 0) {
      throw new ConflictException('同名文件或文件夹已存在');
    }

    const updated = await this.db
      .update(files)
      .set({ name: newName, updatedAt: new Date() })
      .where(and(eq(files.id, fileId), eq(files.userId, userId)))
      .returning();

    if (updated.length === 0) {
      throw new NotFoundException('文件不存在');
    }

    return toFileItem(updated[0]);
  }

  async move(
    fileId: string,
    userId: string,
    targetParentId: string | null,
  ): Promise<FileItem> {
    const file = await this.getById(fileId, userId);

    // Moving to same location is a no-op (but not an error? let's treat as conflict)
    if (file.parentId === targetParentId) {
      return file;
    }

    // Validate target folder exists (if not root)
    if (targetParentId !== null) {
      const targetRows = await this.db
        .select()
        .from(files)
        .where(and(eq(files.id, targetParentId), eq(files.userId, userId)))
        .limit(1);
      if (targetRows.length === 0) {
        throw new NotFoundException('目标目录不存在');
      }
      if (targetRows[0].type !== 'folder') {
        throw new BadRequestException('目标节点不是文件夹');
      }

      // Prevent moving into own subtree
      if (file.type === 'folder') {
        const isDescendant = await this.isDescendant(fileId, targetParentId, userId);
        if (isDescendant) {
          throw new BadRequestException('不能移动到自身的子目录内');
        }
      }
    }

    // Check for duplicate name at target
    const duplicateCondition = this.buildDuplicateCondition(
      userId,
      targetParentId,
      file.name,
    );
    const existing = await this.db
      .select({ id: files.id })
      .from(files)
      .where(and(duplicateCondition, sql`${files.id} != ${fileId}`))
      .limit(1);

    if (existing.length > 0) {
      throw new ConflictException('目标目录下已存在同名文件或文件夹');
    }

    const updated = await this.db
      .update(files)
      .set({ parentId: targetParentId, updatedAt: new Date() })
      .where(and(eq(files.id, fileId), eq(files.userId, userId)))
      .returning();

    if (updated.length === 0) {
      throw new NotFoundException('文件不存在');
    }

    return toFileItem(updated[0]);
  }

  private async isDescendant(
    ancestorId: string,
    targetId: string,
    userId: string,
  ): Promise<boolean> {
    // Check if targetId is inside the subtree of ancestorId
    // Walk up from targetId to root; if we hit ancestorId, it's a descendant
    let currentId: string | null = targetId;

    while (currentId !== null) {
      if (currentId === ancestorId) {
        return true;
      }
      const rows = await this.db
        .select({ parentId: files.parentId })
        .from(files)
        .where(and(eq(files.id, currentId), eq(files.userId, userId)))
        .limit(1);
      if (rows.length === 0) break;
      currentId = rows[0].parentId ?? null;
    }

    return false;
  }

  async remove(fileId: string, userId: string): Promise<void> {
    const file = await this.getById(fileId, userId);

    let totalFreedBytes = 0;
    const idsToDelete: string[] = [fileId];

    if (file.type === 'folder') {
      // Recursively collect all descendants
      const descendantIds = await this.getAllDescendantIds(fileId, userId);
      idsToDelete.push(...descendantIds);

      // Sum up sizes of all files being deleted
      const fileRows = await this.db
        .select({ sizeBytes: files.sizeBytes, type: files.type })
        .from(files)
        .where(inArray(files.id, idsToDelete));

      totalFreedBytes = fileRows.reduce((sum: number, row: FileRow) => {
        if (row.type === 'file') {
          return sum + Number(row.sizeBytes);
        }
        return sum;
      }, 0);
    } else {
      totalFreedBytes = Number(file.sizeBytes);
    }

    // Delete all (FK cascade will handle children too, but we've already collected them)
    await this.db
      .delete(files)
      .where(and(inArray(files.id, idsToDelete), eq(files.userId, userId)));

    // Update user quota
    if (totalFreedBytes > 0) {
      await this.usersService.updateUsedBytes(userId, -totalFreedBytes);
    }
  }

  private async getAllDescendantIds(
    folderId: string,
    userId: string,
  ): Promise<string[]> {
    const allIds: string[] = [];
    let currentLevelIds: string[] = [folderId];

    while (currentLevelIds.length > 0) {
      const children = await this.db
        .select({ id: files.id })
        .from(files)
        .where(
          and(
            inArray(files.parentId, currentLevelIds),
            eq(files.userId, userId),
          ),
        );

      const childIds = children.map((c: { id: string }) => c.id);
      allIds.push(...childIds);
      currentLevelIds = childIds;
    }

    return allIds;
  }

  async createFileRecord(
    userId: string,
    fileData: {
      name: string;
      parentId?: string | null;
      filePath: string;
      bucketId: string;
      sizeBytes: number;
      mimeType?: string;
    },
  ): Promise<FileItem> {
    // Validate parent exists (if not root)
    if (fileData.parentId) {
      const parentRows = await this.db
        .select()
        .from(files)
        .where(and(eq(files.id, fileData.parentId), eq(files.userId, userId)))
        .limit(1);
      if (parentRows.length === 0) {
        throw new NotFoundException('父目录不存在');
      }
      if (parentRows[0].type !== 'folder') {
        throw new BadRequestException('父节点不是文件夹');
      }
    }

    // Check quota
    const hasQuota = await this.usersService.checkQuota(userId, fileData.sizeBytes);
    if (!hasQuota) {
      throw new ConflictException('存储空间不足');
    }

    // Check for duplicate name
    const parentId = fileData.parentId ?? null;
    const duplicateCondition = this.buildDuplicateCondition(
      userId,
      parentId,
      fileData.name,
    );
    const existing = await this.db
      .select({ id: files.id })
      .from(files)
      .where(duplicateCondition)
      .limit(1);

    if (existing.length > 0) {
      throw new ConflictException('同名文件或文件夹已存在');
    }

    const [row] = await this.db
      .insert(files)
      .values({
        userId,
        name: fileData.name,
        type: 'file',
        parentId,
        filePath: fileData.filePath,
        bucketId: fileData.bucketId,
        sizeBytes: fileData.sizeBytes,
        mimeType: fileData.mimeType ?? null,
      })
      .returning();

    // Update user used bytes
    await this.usersService.updateUsedBytes(userId, fileData.sizeBytes);

    return toFileItem(row);
  }

  async getDownloadUrl(
    fileId: string,
    userId: string,
  ): Promise<{ filePath: string; bucketId: string; name: string }> {
    const rows = await this.db
      .select({
        filePath: files.filePath,
        bucketId: files.bucketId,
        name: files.name,
        type: files.type,
      })
      .from(files)
      .where(and(eq(files.id, fileId), eq(files.userId, userId)))
      .limit(1);

    if (rows.length === 0) {
      throw new NotFoundException('文件不存在');
    }

    if (rows[0].type === 'folder') {
      throw new BadRequestException('文件夹不能下载');
    }

    const row = rows[0];
    return {
      filePath: row.filePath ?? '',
      bucketId: row.bucketId ?? '',
      name: row.name,
    };
  }

  async getFilesByParent(userId: string, parentId: string | null): Promise<FileItem[]> {
    const conditions = [eq(files.userId, userId)];
    if (parentId === null) {
      conditions.push(sql`${files.parentId} is null`);
    } else {
      conditions.push(eq(files.parentId, parentId));
    }

    const rows: FileRow[] = await this.db
      .select()
      .from(files)
      .where(and(...conditions))
      .orderBy(asc(files.name));

    return rows.map((row: FileRow) => toFileItem(row));
  }

  private buildDuplicateCondition(
    userId: string,
    parentId: string | null,
    name: string,
  ) {
    if (parentId === null) {
      return and(
        eq(files.userId, userId),
        eq(files.name, name),
        sql`${files.parentId} is null`,
      );
    }
    return and(
      eq(files.userId, userId),
      eq(files.name, name),
      eq(files.parentId, parentId),
    );
  }
}
