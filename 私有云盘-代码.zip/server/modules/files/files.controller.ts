import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Query,
  Param,
  Body,
} from '@nestjs/common';
import { FilesService } from './files.service';
import { FileListQueryDto } from './dto/file-list-query.dto';
import { CreateFolderDto } from './dto/create-folder.dto';
import { RenameFileDto } from './dto/rename-file.dto';
import { MoveFileDto } from './dto/move-file.dto';
import { UploadCompleteDto } from './dto/upload-complete.dto';
import { CurrentUser } from '@server/common/decorators/current-user.decorator';
import type {
  FileItem,
  FileListResponse,
  UserInfo,
} from '@shared/api.interface';

@Controller('api/files')
export class FilesController {
  constructor(private readonly filesService: FilesService) {}

  @Get()
  async list(
    @CurrentUser() user: UserInfo,
    @Query() query: FileListQueryDto,
  ): Promise<FileListResponse> {
    const parentId = query.parentId !== undefined ? query.parentId : null;
    return this.filesService.list(
      user.id,
      parentId,
      query.sortBy,
      query.sortOrder,
      query.search,
      query.type,
    );
  }

  @Get(':id')
  async getById(
    @CurrentUser() user: UserInfo,
    @Param('id') id: string,
  ): Promise<FileItem> {
    return this.filesService.getById(id, user.id);
  }

  @Post('folder')
  async createFolder(
    @CurrentUser() user: UserInfo,
    @Body() dto: CreateFolderDto,
  ): Promise<FileItem> {
    return this.filesService.createFolder(
      user.id,
      dto.name,
      dto.parentId ?? null,
    );
  }

  @Patch(':id/rename')
  async rename(
    @CurrentUser() user: UserInfo,
    @Param('id') id: string,
    @Body() dto: RenameFileDto,
  ): Promise<FileItem> {
    return this.filesService.rename(id, user.id, dto.name);
  }

  @Patch(':id/move')
  async move(
    @CurrentUser() user: UserInfo,
    @Param('id') id: string,
    @Body() dto: MoveFileDto,
  ): Promise<FileItem> {
    return this.filesService.move(id, user.id, dto.targetParentId);
  }

  @Delete(':id')
  async remove(
    @CurrentUser() user: UserInfo,
    @Param('id') id: string,
  ): Promise<void> {
    await this.filesService.remove(id, user.id);
  }

  @Post('upload-complete')
  async uploadComplete(
    @CurrentUser() user: UserInfo,
    @Body() dto: UploadCompleteDto,
  ): Promise<FileItem> {
    return this.filesService.createFileRecord(user.id, {
      name: dto.name,
      parentId: dto.parentId ?? null,
      filePath: dto.filePath,
      bucketId: dto.bucketId,
      sizeBytes: dto.sizeBytes,
      mimeType: dto.mimeType,
    });
  }

  @Get(':id/download-url')
  async getDownloadUrl(
    @CurrentUser() user: UserInfo,
    @Param('id') id: string,
  ): Promise<{ filePath: string; bucketId: string; name: string }> {
    return this.filesService.getDownloadUrl(id, user.id);
  }
}
