import { IsString } from 'class-validator';
import type { RenameFileRequest } from '@shared/api.interface';

export class RenameFileDto implements RenameFileRequest {
  @IsString()
  name!: string;
}
