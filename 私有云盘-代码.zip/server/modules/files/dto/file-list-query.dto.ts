import { IsOptional, IsIn, IsString } from 'class-validator';
import { Transform } from 'class-transformer';
import { FILE_TYPES } from '@shared/api.interface';

export class FileListQueryDto {
  @IsOptional()
  @Transform(({ obj, key }) => (obj[key] === '' ? null : obj[key]))
  @IsString()
  parentId?: string | null;

  @IsOptional()
  @IsIn(['name', 'sizeBytes', 'createdAt', 'updatedAt', 'type'])
  sortBy?: 'name' | 'sizeBytes' | 'createdAt' | 'updatedAt' | 'type';

  @IsOptional()
  @IsIn(['asc', 'desc'])
  sortOrder?: 'asc' | 'desc';

  @IsOptional()
  @IsString()
  search?: string;

  @IsOptional()
  @IsIn(FILE_TYPES)
  type?: 'file' | 'folder';
}
