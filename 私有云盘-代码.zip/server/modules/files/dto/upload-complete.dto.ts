import { IsString, IsOptional, IsInt, Min } from 'class-validator';
import { Type, Transform } from 'class-transformer';

export class UploadCompleteDto {
  @IsString()
  name!: string;

  @IsOptional()
  @Transform(({ obj, key }) => (obj[key] === '' ? null : obj[key]))
  @IsString()
  parentId?: string | null;

  @IsString()
  filePath!: string;

  @IsString()
  bucketId!: string;

  @Type(() => Number)
  @IsInt()
  @Min(0)
  sizeBytes!: number;

  @IsOptional()
  @IsString()
  mimeType?: string;
}
