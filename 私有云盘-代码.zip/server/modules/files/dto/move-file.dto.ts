import { IsOptional, IsString } from 'class-validator';
import { Transform } from 'class-transformer';
import type { MoveFileRequest } from '@shared/api.interface';

export class MoveFileDto implements MoveFileRequest {
  @IsOptional()
  @Transform(({ obj, key }) => (obj[key] === '' ? null : obj[key]))
  @IsString()
  targetParentId!: string | null;
}
