import { IsString, IsOptional } from 'class-validator';
import { Transform } from 'class-transformer';
import type { CreateFolderRequest } from '@shared/api.interface';

export class CreateFolderDto implements CreateFolderRequest {
  @IsString()
  name!: string;

  @IsOptional()
  @Transform(({ obj, key }) => (obj[key] === '' ? null : obj[key]))
  @IsString()
  parentId?: string | null;
}
