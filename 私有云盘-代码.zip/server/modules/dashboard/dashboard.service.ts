import { Injectable } from '@nestjs/common';
import { eq, desc, sql, count } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { Inject } from '@nestjs/common';
import { users, files, shares, apiKeys } from '@server/database/schema';
import type {
  DashboardStats,
  FileItem,
  ShareInfo,
} from '@shared/api.interface';

function toFileItem(row: typeof files.$inferSelect): FileItem {
  return {
    id: row.id,
    name: row.name,
    type: row.type as FileItem['type'],
    parentId: row.parentId ?? null,
    sizeBytes: row.sizeBytes,
    mimeType: row.mimeType ?? null,
    userId: row.userId,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

@Injectable()
export class DashboardService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async getStats(): Promise<DashboardStats> {
    const [
      totalStorageResult,
      totalQuotaResult,
      totalUsersResult,
      totalFilesResult,
      totalApiCallsResult,
      recentUploadsRows,
      recentSharesRows,
      storageByUserRows,
    ] = await Promise.all([
      this.db
        .select({ value: sql<number>`sum(${users.usedBytes})` })
        .from(users),
      this.db
        .select({ value: sql<number>`sum(${users.quotaBytes})` })
        .from(users),
      this.db.select({ value: count() }).from(users),
      this.db
        .select({ value: count() })
        .from(files)
        .where(eq(files.type, 'file')),
      this.db
        .select({ value: sql<number>`sum(${apiKeys.callCount})` })
        .from(apiKeys),
      this.db
        .select()
        .from(files)
        .where(eq(files.type, 'file'))
        .orderBy(desc(files.createdAt))
        .limit(10),
      this.db
        .select({
          share: shares,
          fileName: files.name,
          creatorUsername: users.username,
        })
        .from(shares)
        .innerJoin(files, eq(shares.fileId, files.id))
        .innerJoin(users, eq(shares.createdBy, users.id))
        .orderBy(desc(shares.createdAt))
        .limit(10),
       this.db
        .select({ username: users.username, usedBytes: users.usedBytes, quotaBytes: users.quotaBytes, role: users.role })
        .from(users)
        .orderBy(desc(users.usedBytes))
        .limit(10),
    ]);

    const totalStorageBytes = totalStorageResult[0]?.value
      ? Number(totalStorageResult[0].value)
      : 0;
    const totalQuotaBytes = totalQuotaResult[0]?.value
      ? Number(totalQuotaResult[0].value)
      : 0;
    const totalUsers = Number(totalUsersResult[0]?.value ?? 0);
    const totalFiles = Number(totalFilesResult[0]?.value ?? 0);
    const totalApiCalls = totalApiCallsResult[0]?.value
      ? Number(totalApiCallsResult[0].value)
      : 0;

    const recentUploads: FileItem[] = recentUploadsRows.map(
      (row: typeof files.$inferSelect) => toFileItem(row),
    );

    const recentShares: ShareInfo[] = recentSharesRows.map(
      (row: {
        share: typeof shares.$inferSelect;
        fileName: string;
        creatorUsername: string;
      }) => ({
        id: row.share.id,
        token: row.share.token,
        fileId: row.share.fileId,
        fileName: row.fileName,
        shareType: row.share.shareType as ShareInfo['shareType'],
        hasPassword: !!row.share.password,
        expiresAt: row.share.expiresAt
          ? row.share.expiresAt.toISOString()
          : null,
        allowDownload: row.share.allowDownload,
        createdBy: row.creatorUsername,
        viewCount: row.share.viewCount,
        createdAt: row.share.createdAt.toISOString(),
      }),
    );

    const storageByUser: { username: string; usedBytes: number; quotaBytes: number; role: string }[] =
      storageByUserRows.map(
        (row: { username: string; usedBytes: number; quotaBytes: number; role: string }) => ({
          username: row.username,
          usedBytes: Number(row.usedBytes),
          quotaBytes: Number(row.quotaBytes),
          role: row.role,
        }),
      );

    return {
      totalStorageBytes,
      totalQuotaBytes,
      totalUsers,
      totalFiles,
      totalApiCalls,
      recentUploads,
      recentShares,
      storageByUser,
    };
  }
}
