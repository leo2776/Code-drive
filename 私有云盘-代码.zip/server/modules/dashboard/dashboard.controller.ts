import { Controller, Get, Req, ForbiddenException } from '@nestjs/common';
import type { Request } from 'express';
import { DashboardService } from './dashboard.service';
import type { DashboardStats } from '@shared/api.interface';

@Controller('api/dashboard')
export class DashboardController {
  constructor(private readonly dashboardService: DashboardService) {}

  private checkAdmin(req: Request): void {
    if (req.user.role !== 'admin') {
      throw new ForbiddenException('需要管理员权限');
    }
  }

  @Get('stats')
  async getStats(@Req() req: Request): Promise<DashboardStats> {
    this.checkAdmin(req);
    return this.dashboardService.getStats();
  }
}
